 	class Jprog01
 	{
 	  public static void main(String[] args)
 	    {
 	    	System.out.println("Ankara T�rkiye'nin ba�kentidir.");
 	    }
 	}