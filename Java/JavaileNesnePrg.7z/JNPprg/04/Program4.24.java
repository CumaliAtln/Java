    class �li�kiselOperat�rler
    {
        static void main(String[] args)
        {
            int x = 10;
            int y = 4;
            bool sonu�;

            sonu� = (x > y);
            System.out.println("x > y = {0}", sonu�);
            sonu� = (x < y);
            System.out.println("x < y = {0}", sonu�);
            sonu� = (x <= y);
            System.out.println("x <= y = {0}", sonu�);
            sonu� = (x >= y);
            System.out.println("x >= y = {0}", sonu�);
            sonu� = (x == y);
            System.out.println("x == y = {0}", sonu�);
            sonu� = (x != y);
            System.out.println("x != y = {0}", sonu�);
        }
    }
}