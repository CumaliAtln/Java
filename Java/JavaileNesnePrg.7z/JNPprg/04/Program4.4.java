class Demo {

	public static void main(String[] args) {

		byte b = 12;
		short s = 5;
		int n, x = 32, y = 7;
		long k = 4;
		float r = 23.5f;
		double t = 3.7;
		float ff;
		double dd;

		n = x / y;
		System.out.println("x/y: " + n);

		ff = (float) x / y;
		System.out.println("x/y: " + ff);

		ff = x / (float) y;
		System.out.println("x/y: " + ff);

		ff = (float) x / (float) y;
		System.out.println("x/y: " + ff);

		ff = (float) (x / y);
		System.out.println("x/y: " + ff);

		dd = (double) x / y;
		System.out.println("x/y: " + dd);

		dd = x / (double) y;
		System.out.println("x/y: " + dd);

		dd = (double) x / (double) y;
		System.out.println("x/y: " + dd);

		dd = (double) (x / y);
		System.out.println("x/y: " + dd);
	}
}