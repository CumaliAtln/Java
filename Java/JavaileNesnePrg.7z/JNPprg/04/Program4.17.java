class Demo {

	public static void main(String[] args) {

		int a = 100, b = 9;
		// a+=b ==> a = (a-b)
		System.out.print("a+b  = " + (a + b)); 
		a = 100; b = 9;
		System.out.println(" |   a+=b = " + (a+=b) );
		a = 100; b = 9;
		// a-=b ==> a = (a-b)
		System.out.print ("a-b = " + (a - b));
		a = 100; b = 9;
		System.out.println("   |   a-=b = " + (a -= b));
		a = 100; b = 9;
		// a*=b ==> a = a*b
		System.out.print("a*b  = " + (a * b));
		a = 100; b = 9;
		System.out.println(" |   a*=b = " + (a *= b));
		a = 100; b = 9;
		// a/=b ==> a = a/b
		System.out.print("a / b = " + (a / b));
		a = 100; b = 9;
		System.out.println(" |   a/=b = " + (a /= b));
		a = 100; b = 9;
		// a%=b ==> a = a%b
		System.out.print("a % b  = " + (a % b));
		a = 100; b = 9;
		System.out.println(" |   a%=b = " + (a %= b));
		a = 100; b = 9;
	}
}