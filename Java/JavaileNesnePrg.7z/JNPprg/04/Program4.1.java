class Demo {
	public static void main(String[] args) {
		int x = 25;
		int y = 5;
		int result;

		System.out.println("x + y = " + (x + y));
		System.out.println("x - y = " + (x - y));

		System.out.println("x * y = " + (x * y));
		System.out.println("x / y = " + (x / y));
	}
}