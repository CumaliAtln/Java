class Demo {

	public static void main(String[] args) {

        int x = 5;
        int y = 4;
        System.out.printf("x=%d ve y = %d ise x +=y = %d  \n ", x, y , x += y);
        System.out.printf("x=%d ve y = %d ise x -=y = %d  \n ", x, y , x -= y);
        System.out.printf("x=%d ve y = %d ise x *=y = %d  \n ", x, y , x *= y);
        System.out.printf("x=%d ve y = %d ise x /=y = %d  \n ", x, y , x /= y);
        System.out.printf("x=%d ve y = %d ise xmody = %d  \n ", x, y , (x %=y));
	}
}