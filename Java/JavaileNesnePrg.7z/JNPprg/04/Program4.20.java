class Test
{
    static bool aaaa()
    {
        System.out.println("aaaa fonksiyonu �a�r�ld�");
        return false;
    }

    static bool bbbb()
    {
        System.out.println("bbbb fonksiyonu �a�r�ld�");
        return true;
    }

    public static void main()
    {
        System.out.println("regular AND:");
        System.out.println("Sonu� : {0}", aaaa() & bbbb());
        System.out.println("k�sa-devre AND:");
        System.out.println("Sonu� : {0}", aaaa() && bbbb());
    }
}