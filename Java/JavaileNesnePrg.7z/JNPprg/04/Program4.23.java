class Test
{
  static bool cccc()
  {
   System.out.println("cccc metodu �a�r�ld�");
    return true;
    }

  static bool dddd()
  {
   System.out.println("dddd metodu �a�r�ld�");
    return false;
  }

    public static void main()
  {
    System.out.println("regular OR:");
    System.out.println("sonu� : {0}", cccc() | dddd());
    System.out.println("k�sa-devre OR:");
    System.out.println("sonu� :� {0}", cccc() || dddd());
  }
}