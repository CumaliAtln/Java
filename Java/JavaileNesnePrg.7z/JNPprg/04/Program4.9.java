class Demo {

	public static void main(String[] args) {

		int n = +1;
		System.out.println(n);

		n--;
		System.out.println(n);

		n++;
		System.out.println(n);

		n = -n;
		System.out.println(n);
		boolean bool = false;

		System.out.println(bool);
		System.out.println(!bool);
	}
}