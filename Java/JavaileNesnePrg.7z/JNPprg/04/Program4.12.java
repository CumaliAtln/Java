class Demo {

	public static void main(String[] args) {

		int n = 14;
		float x = 14.3f;

		System.out.printf("n = %d iken --n = %d ve n= %d olur. \n", n, --n, n);
		System.out.printf("n = %d iken ++n = %d ve n= %d olur. \n", n, ++n, n);
		System.out.printf("n = %d iken n-- = %d ve n= %d olur. \n", n, n--, n);
		System.out.printf("n = %d iken n++ = %d ve n= %d olur. \n", n, n++, n);

		System.out.println();

		System.out.printf("x = %f iken --x = %f ve x= %f olur. \n", x, --x, x);
		System.out.printf("x = %f iken ++x = %f ve x= %f olur. \n", x, ++x, x);
		System.out.printf("x = %f iken x-- = %f ve x= %f olur. \n", x, x--, x);
		System.out.printf("x = %f iken x++ = %f ve x= %f olur. \n", x, x++, x);

	}
}