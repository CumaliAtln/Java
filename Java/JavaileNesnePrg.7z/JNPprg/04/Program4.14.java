class Demo {

	public static void main(String[] args) {

		float x = 7.37f;
		System.out.printf("x=%f ise --x * x++ = %f \n ", x, ++x * ++x); x = 7.37f;
		System.out.printf("x=%f ise --x * ++x = %f \n ", x, ++x * --x); x = 7.37f;
		System.out.printf("x=%f ise ++x * x-- = %f \n ", x, --x * --x); x = 7.37f;
		System.out.printf("x=%f ise x-- * ++x = %f \n ", x, --x * ++x); x = 7.37f;
		System.out.println();
		System.out.printf("x=%f ise x++ * x++ = %f \n ", x, x++ * x++); x = 7.37f;
		System.out.printf("x=%f ise x-- * x-- = %f \n ", x, x-- * x--); x = 7.37f;
		System.out.printf("x=%f ise x++ * x-- = %f \n ", x, x++ * x--); x = 7.37f;
		System.out.printf("x=%f ise x-- * x++ = %f \n ", x, x-- * x++); x = 7.37f;
		System.out.println();
		System.out.printf("x=%f ise x-- * x-- = %f \n ", x, ++x * x++); x = 7.37f;
		System.out.printf("x=%f ise x++ * x++ = %f \n ", x, ++x * x--); x = 7.37f;
		System.out.printf("x=%f ise x-- * x++ = %f \n ", x, --x * x++); x = 7.37f;
		System.out.printf("x=%f ise --x * --x = %f \n ", x, --x * x--); x = 7.37f;
	}
}