class Demo {

	public static void main(String[] args) {

		int x = 5;
		System.out.printf("x = %d  iken \n ", x);
		System.out.printf("++x  = %d \n ", ++x);

		x = 5;
		System.out.printf("x++  = %d (��nk� i�leme girmedi) \n ", x++);
		x = 5;
		System.out.printf("x--  = %d (��nk� i�leme girmedi) \n ", x--);
		x = 5;
		System.out.printf("--x  = %d  \n ", --x);
	}
}