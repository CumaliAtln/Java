class Demo {

	public static void main(String[] args) {
		int m = 25;
		int n = 4;
		int p = m / n;
		float x = m / n;
		double y = m / n;
		
		System.out.println("p =  " + p);
		System.out.println("x =  " + x);
		System.out.println("y =  " + y);
	}
}