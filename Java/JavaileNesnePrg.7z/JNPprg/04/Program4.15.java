class Demo {

	public static void main(String[] args) {

        int a;
        float y, sonu�;

        a = 3;
        y = 7.45f;

        sonu� = a + y;
        System.out.printf("%d + %f = %f \n ", a, y, sonu�);

        sonu� = a - y;
        System.out.printf("%d - %f = %f \n ", a, y, sonu�);

        sonu� = a * y;
        System.out.printf("%d * %f = %f \n ", a, y, sonu�);

        sonu� = a / y;
        System.out.printf("%d / %f = %f \n ", a, y, sonu�);

        sonu� = (float)a / (float)y;
        System.out.printf("%d / %f = %f \n ", a, y, sonu�);

        sonu� = a % y;
        System.out.printf("%d mod %f = %f \n ", a, y, sonu�);
    }
}