class Demo {

	public static void main(String[] args) {

		{
			double x = 17.36;
			double y = 5.61;
			double sonu� = x % y;
			System.out.println("x % y = " + sonu�);
		}
	}
}