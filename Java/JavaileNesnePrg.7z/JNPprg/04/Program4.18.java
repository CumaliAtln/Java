class Demo {

	public static void main(String[] args) {

class Demo {

	public static void main(String[] args) {

		float x = 3.67f;
		float y = 2.3f;
		System.out.printf("x = %f ve y = %f  \n ", x, y);
		System.out.printf("(x + y)    ==> %f  \n ", x + y);
		System.out.printf("(x += y)   ==> %f  \n ", (x += y));

		System.out.println();

		System.out.printf(" x = (x - y)  ==> %f  \n ", (x - y));
		System.out.printf("x = (x -= y) ==> %f  \n ", (x-=y));

		System.out.println();

		System.out.printf(" x = (x * y) ==>    %f  \n ", x * y);
		System.out.printf("(x *= y)    ==>      %f  \n ", x *= y);

		System.out.println();

		System.out.printf("x = (x / y)    ==>  %f  \n ", x / y);
		System.out.printf("x =  (x /= y) ==> %f  \n ", x /= y);

		System.out.println();

		System.out.println("x = (x % y)  ==> " + (x % y));
		System.out.println(" (x %= y)    ==> " + (x %= y));
	}
}