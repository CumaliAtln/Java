class Unary
{
    public static void main()
    {
        int unary = 0;
        int �nelArt�m;
        int �nelEksim;
        int sonalArt�m;
        int sonalEksim;
        int art�Say�;
        int eksiSay�;
        sbyte bitselNOT;
        bool mant�ksalNOT;

        �nelArt�m = ++unary;
        System.out.println("�nel Artm  : {0}", �nelArt�m);

        �nelEksim = --unary;
        System.out.println("�nel Eksim : {0}", �nelEksim);

        sonalEksim = unary--;
        System.out.println("Sonal Art�m: {0}", sonalEksim);

        sonalArt�m = unary++;
        System.out.println("Sonal Eksim: {0}", sonalArt�m);

        System.out.println("Unary: {0}", unary);

        art�Say� = -sonalArt�m;
        System.out.println("Art� : {0}", art�Say�);

        eksiSay� = +sonalArt�m;
        System.out.println("Eksi : {0}", eksiSay�);

        bitselNOT = 0;
        bitselNOT = (sbyte)(~bitselNOT);
        System.out.println("Bitwise Not  : {0}", bitselNOT);

        mant�ksalNOT = false;
        mant�ksalNOT = !mant�ksalNOT;
        System.out.println("Mant�ksal Not: {0}", mant�ksalNOT);
    }
}