class Kalan {

  public static void main (String args[]) {

	    int i = 17;
	    int j = 4;

	    System.out.println("i   = " + i);
	    System.out.println("j   = " + j);

	    int k = i % j;
	    System.out.println("i%j = " + k);
	  }
	}