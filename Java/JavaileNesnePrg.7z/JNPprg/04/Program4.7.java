class Demo {

	public static void main(String[] args) {

		int n = 41;
		int m = 7;
		double y = 7;
		
		System.out.println("n % m = " + n % m);
		System.out.println("n % y = " + n % y);
	}
}