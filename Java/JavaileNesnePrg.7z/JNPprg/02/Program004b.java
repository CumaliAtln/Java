class
Program004b
{
Public static

void
main()

{
System.out.println("Merhaba Java! ");
}
}