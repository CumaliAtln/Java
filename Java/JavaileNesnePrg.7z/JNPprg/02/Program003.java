public class Program003 {
	public static void main(String[] args)
	{
		System.out.println("Merhaba Java! ")
	}
}