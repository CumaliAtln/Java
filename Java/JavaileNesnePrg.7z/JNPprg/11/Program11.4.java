public class PublicDemo {

	public String text = "Cumhuriyet Bayram�";

	public String getText() {
		return text;
	}

	public static void main(String[] args) {
		PublicDemo pd = new PublicDemo();
		System.out.println("public anl�k de�i�ken : " + pd.text);
		System.out.println("public metot          : " + pd.getText());
	}
}