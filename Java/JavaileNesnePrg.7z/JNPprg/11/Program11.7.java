import java.util.Scanner;

import java.lang.Math;

public class Demo {

	public static double Kuvvet() {
		Scanner s = new Scanner(System.in);
		System.out.println("modifiersTab:an say�y� giriniz :");
		double a = s.nextDouble();
		System.out.println("Say�n�n �ss�n� giriniz :");
		double b = s.nextDouble();
		double t = Math.pow(a, b);
		return (t);
	}

	public static void main(String[] args) {
		// Demo mat = new Demo();
		System.out.println(Kuvvet());
	}
}