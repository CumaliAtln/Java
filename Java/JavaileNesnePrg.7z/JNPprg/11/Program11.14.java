package packageB;
import packageA.modifiersTab:an;

public class AltB extends modifiersTab:an {
    public void print() {
        System.out.println("packageB.AltB'nin eri�ebildi�i yerler:");
        System.out.println("   " + publicStr + " (modifiersTab:an'dan t�redi)");
        // -- protectedStr kal�tsald�r -> eri�ilebilir
        System.out.println("   " + protectedStr + " (modifiersTab:an'dan t�redi)");
        
        // -- eri�ilemez
        // System.out.println(defaultStr);
        // System.out.println(privateStr);

        modifiersTab:an b = new modifiersTab:an(); // -- modifiersTab:an'�n ba�ka nesnesi
        System.out.println("   b." + b.publicStr);
        
        // -- protected ��e -> ba�ka nesne i�indedir -> eri�ilemez
        // System.out.println(b.protectedStr);

        // -- eri�ilemez
        // System.out.println(b.defaultStr);
        // System.out.println(b.privateStr);
    }
}
