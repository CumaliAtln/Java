public class PrivateDemo {

	private String str = "Ankara ba�kenttir.";

	public String metinYaz() {
		return str;
	}

	public static void main(String[] args) {
		altPrivateDemo belirtke = new altPrivateDemo();
		// private de�i�kene eri�emez
		System.out.println("public anl�k de�i�ken : " + belirtke.str);
		System.out.println("public metot          : " + belirtke.metinYaz());
	}
}

class altPrivateDemo extends PrivateDemo {
	public String altMetinYaz() {
		// private de�i�kene eri�emez
		return str;
	}
}