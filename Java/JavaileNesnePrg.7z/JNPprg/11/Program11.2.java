public class NesneSay {
    private static int ka�Nesne = 0;

    protected static int say() {
        return ka�Nesne;
    }

    private static void nesneEkle() {
        ka�Nesne++;
    }

    NesneSay() {
        NesneSay.nesneEkle(); 
    }

    public static void main(String[] args) {
        System.out.println(NesneSay.say() + " dan ba�layarak");
        for (int i = 0; i < 1000; ++i){
            new NesneSay();
        }
        System.out.println(NesneSay.say() + " nesne yaratt�");
    }
}