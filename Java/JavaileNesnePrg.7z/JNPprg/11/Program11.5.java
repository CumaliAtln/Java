public class ProtectedDemo {

	protected String str = "�stanbul b�y�k bir kenttir.";

	public String metinYaz() {
		return str;
	}

	public static void main(String[] args) {
		altProtectedDemo belirtke = new altProtectedDemo();
		// hatas�z �al���r
		System.out.println("public anl�k de�i�ken : " + belirtke.str);
		System.out.println("public metot          : " + belirtke.metinYaz());
	}
}

class altProtectedDemo extends ProtectedDemo {
	public String altMetinYaz() {
		// hatas�z �al���r
		return str;
	}
}