class StaticDemo {

    static int a = 18;
    static double b;

    static void veriYaz(int x) {
        System.out.println("x = " + x);
        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }

    public static void main(String args[]) {
        veriYaz(73);
    }
}
