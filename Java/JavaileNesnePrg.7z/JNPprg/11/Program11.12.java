package packageA;

public class AltA extends modifiersTab:an {

    public void print() {

        System.out.println("packageA.AltA'n�n eri�ebildi�i ��eler:");
        System.out.println("  " + publicStr + " (modifiersTab:an'dan t�redi)");
        System.out.println("  " + protectedStr + " (modifiersTab:an'dan t�redi)");
        System.out.println("  " + defaultStr + " (modifiersTab:an'dan t�redi)");

        // �st s�n�f�n private ��elerine eri�emez
        // System.out.println(privateStr);

        modifiersTab:an b = new modifiersTab:an(); // -- ba�ka modifiersTab:an nesnesi

        System.out.println("   b." + b.publicStr);
        System.out.println("   b." + b.protectedStr);
        System.out.println("   b." + b.defaultStr);

        // -- eri�emez
        // System.out.println(b.privateStr);
    }
}
