package packageA;

public class BBB {

    public void print() {

        System.out.println("packageA.BBB'nin eri�ebildi�i ��eler:");

        modifiersTab:an b = new modifiersTab:an();

        System.out.println("    b." + b.publicStr);
        System.out.println("    b." + b.protectedStr);
        System.out.println("    b." + b.defaultStr);

				// eri�emez
        // System.out.println(b.privateStr);
    }
}
