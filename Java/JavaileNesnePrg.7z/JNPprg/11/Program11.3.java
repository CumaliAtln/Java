public class A {
    // do�al eri�im belirtkesi; anl�k de�iken bildirimidir
    String text = "Sab�r ac�d�r ama meyvesi tatl�d�r. (J.J.Rousseau)";

    public String getText() {
        return text;
    }

    public static void main(String[] args) {
        AA aa = new AA();
        // eri�ilebilir
        System.out.println("public anl�k de�i�ken : " + aa.text);
        System.out.println("public metot          : " + aa.getText());
    }
}

class AA extends A {  // d�� alts�n�f
    public String altGetText() {
        // eri�ilebilir
        return text;  // �st s�n�f ��esi
    }
}