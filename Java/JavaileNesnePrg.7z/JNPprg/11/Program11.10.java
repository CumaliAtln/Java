class Say�lar {
    int a; 					// do�al eri�im
    public int b; 			// public eri�im
    private int c; 			// private eri�im
    // c ye eri�en metot
    void setc(int i) { 	// c ye de�er atar
        c = i;
    }

    int getc() { 			// c nin de�erini verir
        return c;
    }
}

public class Test {
    public static void main(String[] args) {
        Say�lar s = new Say�lar();
        // a ile b ye direkt eri�ilebilir
        s.a = 10;
        s.b = 20;

        // s.c = 100; // Hata!
        // c ye eri�mek i�in s�n�f�n metodu kullan�lmal�
        s.setc(100); // ge�erli

        System.out.println("a, b, c: " + s.a + " " + s.b + " " + s.getc());
    }
}