class Test {
	int a; 					// do�al eri�im
	public int b; 	// public eri�im
	private int c; 	// private eri�im

	// c ye eri�en metot
	void setc(int i) { // c ye de�er atar
		c = i;
	}

	int getc() { // c nin de�erini verir
		return c;
	}

	public static void main(String[] args) {
		Test t = new Test();
		t.setc(25);
		t.a = t.getc() / 5;
		t.b = 2 * t.a;
		System.out.println(t.a);
		System.out.println(t.b);
		System.out.println(t.c);
	}
}