class Veriler 
	{

    static int a = 87;
    static float b = 35.8f;

    public void say�Yaz() 
		{
        System.out.printf("a = %d %nb = %f %n ", a, b);
    }
  }

public class StaticDemo 
 {

    public static void main(String args[]) 
		{
        Veriler veri = new Veriler();
        veri.say�Yaz();
    }
 }
