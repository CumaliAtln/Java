package packageA;

public class Eri�im {

    public String publicStr = "publicString";
    protected String protectedStr = "protectedString";
    String defaultStr = "defaultString";
    private String privateStr = "privateString";

    public void print() {

        System.out.println("packageA.Eri�im'�n eri�ebildi�i ��eler:");
        System.out.println("    " + publicStr);
        System.out.println("    " + protectedStr);
        System.out.println("    " + defaultStr);
        System.out.println("    " + privateStr);

        Eri�im b = new Eri�im(); // -- Eri�im'�n ba�ka nesnesi

        System.out.println("    b." + b.publicStr);
        System.out.println("    b." + b.protectedStr);
        System.out.println("    b." + b.defaultStr);
        System.out.println("    b." + b.privateStr);
    }
    public static void main(String[] args){
        Eri�im mb = new Eri�im();
        mb.print();
    }
}
