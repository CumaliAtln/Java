package packageB;
import packageA.modifiersTab:an;

public class CCC {

    public void print() {

        System.out.println("packageB.CCC'nin eri�ebildi�i ��eler:");

        modifiersTab:an b = new modifiersTab:an();

        System.out.println("    b." + b.publicStr);

        // -- eri�emez
        // System.out.println(b.protectedStr);
        // System.out.println(b.defaultStr);
        // System.out.println(b.privateStr);
    }
}
