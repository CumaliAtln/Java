class Test
{
  final int value=12;
  // Sabit bildirimi
  public static final int BOXWIDTH = 6;
  static final String TITLE = "M�d�r";
  
  public void changeValue()
	{
     value = 12; // hata verir
  }
}
