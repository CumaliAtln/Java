import packageA.*;
import packageB.*;

// -- eri�im testi

public class Test {

    public static void main(String[] args) {

        /**
         * B�t�n s�n�flar public oldu�undan
         * Test s�n�f� onlara eri�ebilir
         */

        new packageA.modifiersTab:an().print();
        new packageA.AltA().print();
        new packageA.BBB().print();
        new packageB.AltB().print();
        new packageB.CCC().print();
    }
}
