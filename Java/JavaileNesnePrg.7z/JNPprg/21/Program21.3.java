class Overload {
    static char ch;
    static int m,n ;
    static double d ;
    
    void test(char c) {
        ch = c;
        System.out.println(ch);
    }

    void test(int a, int b) {
        m= a;
        n= b;
        System.out.println(m+n);
    }

    double test(double r) {
        d = r;
        System.out.println("say� :" + d);
        return d*d ;
    }

    public static void main(String args[]) {
        Overload overload = new Overload();
        overload.test('A');
        overload.test(5, 10);
        overload.test(3.2);
    }
}