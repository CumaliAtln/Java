public class Demo
{
    static public class Emekci
    {
        public void ad()
        {
            System.out.println("Turgut");
        }
    }
    static public class Personel extends Emekci
    {
        @Override
        public void ad()
        {
            System.out.println("Melih");
        }
    }
    static public class Kadrolu  extends Personel
    {
        @Override
        public void ad()
        {
            System.out.println("Deniz");
        }
    }
    static public class �cretli  extends Personel
    {
        @Override
        public void ad()
        {
            System.out.println("Kutay");
        }
    }
    static public void adYaz(Emekci Birisi)
    {
        Birisi.ad();
    }
    public static void main(String[] args) 
    {
        Emekci 		Ar�1 = new Emekci();
        Personel 	Ar�2 = new Personel();
        Kadrolu 	Ar�3 = new Kadrolu();
        �cretli 	Ar�4 = new �cretli();
				
        adYaz(Ar�1);
        adYaz(Ar�2);
        adYaz(Ar�3);
        adYaz(Ar�4);
    }
} 