// ko�ma an� �oklubi�emi
class Sekil {
    double boyut1;
    double boyut2;

    Sekil(double a, double b) {
        boyut1 = a;
        boyut2 = b;
    }

    double alan() {
        System.out.println("�eklin alan� hen�z tan�ml� de�il! ");
        return 0;
    }
}

class Dikdortgen extends Sekil {
    Dikdortgen(double a, double b) {
        super(a, b);
    }

    // Dikd�rtgen i�in override alan
    double alan() {
        System.out.println("Dikd�rtgenin alan�.");
        return boyut1 * boyut2;
    }
}

class Ucgen extends Sekil {
    Ucgen(double a, double b) {
        super(a, b);
    }

    // ��gen i�in override alan
    double alan() {
        System.out.println("��genin alan�.");
        return boyut1 * boyut2 / 2;
    }
}

public class AlanBul {

    public static void main(String args[]) {
        Sekil f = new Sekil(15, 15);
        Dikdortgen r = new Dikdortgen(7, 4);
        Ucgen t = new Ucgen(9, 6);

        Sekil ref;

        ref = r;
        System.out.println("Alan = " + ref.alan());

        ref = t;
        System.out.println("Alan = " + ref.alan());

        ref = f;
        System.out.println("Alan = " + ref.alan());
    }
}
