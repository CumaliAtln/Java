abstract class �ekil { 

    void �iz(){
        System.out.println("Do�ru �iz");
    }

    abstract void sil(); 
}

class Daire extends �ekil {
    void sil() { 
        System.out.println("Daire.sil()"); 
    }
}

class Kare extends �ekil {
    void sil() { 
        System.out.println("Kare.sil()"); 
    }
}

class ��gen extends �ekil {
    void sil() { 
        System.out.println("��gen.sil()");
    }
}

public class �ekilSil {
    public static �ekil random�ekil() {
        switch((int)(Math.random() * 3)) {
            default: ;; // bir �ey yapma   
            case 0: return new Daire();
            case 1: return new Kare();
            case 2: return new ��gen();
        }
    }

    public static void main(String[] args) {
        �ekil[] s = new �ekil[9];
        // �ekilleri arraye koy
        for(int i = 0; i < s.length; i++)
            s[i] = random�ekil();
        //  �iz() metoduna farkl� i�ler yapt�r (�ok bi�emlilik)
        for(int i = 0; i < s.length; i++)
            s[i].�iz();
    }
} 