public class PersonTest {

	public static void main(String[] args) {
		Person person = new Person("Genel M�d�r", 10,50);
		Mudur mudur = new Mudur("M�d�r", 10,40);
		Teknisyen teknisyen = new Teknisyen("Teknisyen", 10,30);
		Sekreter sekreter = new Sekreter("Sekreter",10,20);
		System.out.println("Genel M�d�r:" + person.mesaiHesapla());

		person = mudur;
		System.out.println("M�d�r      :" +person.mesaiHesapla());
		person = teknisyen;
		System.out.println("Teknisyen  :" +person.mesaiHesapla());
		person = sekreter;
		System.out.println("Sekreter   :" +person.mesaiHesapla());
	}
}

class Person {
	String name;
	double saat;
	double saat�creti;
	
	public Person(String s, double h, double f)
	{
		name = s;
		saat = h;
		saat�creti = f;
	}
	
	public double mesaiHesapla() {
		
		return saat * saat�creti;
	}
}

class Mudur extends Person {
	public Mudur(String m, double zaman, double �cr)
	{
		super(m,zaman,�cr);
	}

	public double mesaiHesapla() {
		return   saat* saat�creti;
	}
}

class Teknisyen extends Person {
	public Teknisyen(String m, double zaman, double �cr)
	{
		super(m,zaman,�cr);
	}

	public double mesaiHesapla() {
		return saat* saat�creti;
	}
}
class Sekreter extends Person {
	public Sekreter(String m, double zaman, double �cr)
	{
		super(m,zaman,�cr);
	}
	public double mesaiHesapla() {
		return saat* saat�creti;
	}
}