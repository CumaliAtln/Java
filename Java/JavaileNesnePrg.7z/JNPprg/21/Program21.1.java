	public static double Toplama (int m, double n)
		{double toplam;
			toplam = m + n;
			return toplam;
		}