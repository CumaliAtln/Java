class Ata {

    public void mesajYaz(){
        System.out.println("Ata metodu");
    }
}

class O�ul extends Ata{
    public static void main(String args[]){
        (new O�ul()).mesajYaz();
    }

    public void mesajYaz(){
        System.out.println("O�ul metodu");
    }
}

public class AtaO�ul {
    public static void main(String[] args) {

        Ata ata = new Ata();
        O�ul ogul = new O�ul();

        ata.mesajYaz();
        ogul.mesajYaz();
    }
}