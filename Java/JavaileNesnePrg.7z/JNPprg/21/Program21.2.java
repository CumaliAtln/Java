public class Mesaj {

    public void mesajYaz(String mesaj){
        System.out.print(mesaj);
    }

    public void mesajYaz(String mesaj, int num){
        System.out.println(mesaj + " " + num);
    }

    public static void main(String[] args) {

        Mesaj m = new Mesaj();
        m.mesajYaz("Merhaba ");
        m.mesajYaz("Java ", 7 );
    }
}