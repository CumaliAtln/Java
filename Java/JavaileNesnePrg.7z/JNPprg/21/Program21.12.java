public class Kay�t
{
    private String ad;
    private String soyAd;
    private int numara;

    public Kay�t(String ad, String soyAd, int numara)
    {
        this.ad = ad;
        this.soyAd = soyAd;
        this.numara = numara;
    }

    public String adGetir()
    {
        return ad + " " + soyAd;
    }

    public int numaraGetir()
    {
        return numara;
    }

    public String kay�tYaz() 
    {
        String s =   numara + "\n" + adGetir();
        return s;
    }

    public static void main(String[] args){
        Kay�t ref = new Kay�t("Victor", "Hugo", 123 ); 
        System.out.print(ref.adGetir());
        System.out.println(" " + ref.numaraGetir());
        System.out.print(ref.kay�tYaz());
    } 
}