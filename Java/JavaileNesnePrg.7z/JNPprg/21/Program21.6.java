// ko�ma an� �oklubi�emi
class A {
    void kimGeldi() {
        System.out.println("�imdi A 'daki kimGeldi methodu �a�r�ld�.");
    }
}

class B extends A {
    // override kimGeldi()
    void kimGeldi() {
        System.out.println("�imdi B 'deki kimGeldi methodu �a�r�ld�. ");
    }
}

class C extends A {
    // override kimGeldi()
    void kimGeldi() {
        System.out.println("�imdi C 'deki kimGeldi methodu �a�r�ld�. ");
    }
}

public class Ko�ma {

    public static void main(String args[]) {
        A a = new A(); // A tipinden nesne
        B b = new B(); // B tipinden nesne
        C c = new C(); // C tipinden nesne
        A r; // A tipinden bir referans (i�aret�i, pointer)

        r = a; // r referans� A 'n�n bir nesnesini i�aret ediyor
        r.kimGeldi(); // A ' daki kimGeldi metodunu �a��r�yor

        r = b; // r referans� B 'nin bir nesnesini i�aret ediyor
        r.kimGeldi(); // B ' deki kimGeldi metodunu �a��r�yor

        r = c; // r referans� C 'nin bir nesnesini i�aret ediyor
        r.kimGeldi(); // C ' deki kimGeldi metodunu �a��r�yor
    }
}