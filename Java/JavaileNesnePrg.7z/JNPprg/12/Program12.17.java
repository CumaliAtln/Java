package metotlar;

import java.util.Scanner;

class EKOK {
	static int n, m, ekok;

	/* a ve b ekok'u bulunacak say�lar */
	static int ekokBul(int a, int b) {
		int n;
		for (n = 1;; n++) {
			if (n % a == 0 && n % b == 0)
				return n;
		}
	}