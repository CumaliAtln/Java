package metotlar;

class FibonacciSay�lar� {
	static long saya� = 0;

	public static void main(String[] args) {
		for (int i = 1; i <= 45; i++)
			System.out.printf("Fibonacci(%d) = %d  i�in %d ad�m at�d� %n", i,
					Fibonacci(i), saya�);
	}

	static int Fibonacci(int n) {
		saya�++;
		if (n < 2)
			return n;
		else
			return Fibonacci(n - 1) + Fibonacci(n - 2);
	}
}