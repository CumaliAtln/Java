package metotlar;

import java.util.Scanner;

class Demo {
	static double d;

	static double logBul(double y) {
		return Math.log(y);
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Logaritmas� al�nacak say�y� giriniz: ");
		d = scan.nextDouble();
		System.out.println(logBul(d));
	}
}