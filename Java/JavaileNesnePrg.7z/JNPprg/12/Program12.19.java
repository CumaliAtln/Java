package metotlar;

import java.util.Scanner;

class Demo {
	static int n, m, ebob;

	/* a ve b ebob'i bulunacak say�lar */
	static int ebobBul(int a, int b) {
		int kalan;

		while (b != 0) {
			kalan = a % b;
			a = b;
			b = kalan;
		}

		return a;
	}

	public static void main(String[] args) {
	
	Scanner scan = new Scanner(System.in);
	System.out.println("ebob 'i bulunacak say�lar�n ilkini giriniz:");
		n = scan.nextInt();

	System.out.println("ebob'i bulunacak say�lar�n ikincisini giriniz:");
		m = scan.nextInt();

		System.out.println(ebobBul(n, m));
	}
}