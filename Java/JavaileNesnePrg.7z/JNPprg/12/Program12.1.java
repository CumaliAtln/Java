	package metotlar;
	
	public class Kare {
	
			static int n;
	
			public static void main(String[] args) {
					n = karesiniBul(9);
					System.out.println(n);
			}
	
			static int karesiniBul(int x) {
					int y;
					y = x * x;
					return y;
			}
	}
