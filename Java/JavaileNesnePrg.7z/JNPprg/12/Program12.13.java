package metotlar;

import java.util.Scanner;

class Demo {
	static double d;
	
	// say�n�n karek�k�n� bulur
	public static double kareK�k(double num) {
		if (0 == num) {
			return 0;
		} // S�f�ra b�lmeyi �nler
		double r = (num / 2) + 1; // �lk tahmin
		double r1 = (r + (num / r)) / 2;
		while (r1 < r) {
			r = r1;
			r1 = (r + (num / r)) / 2;
		}
		return r;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Karek�k� al�nacak say�y� giriniz: ");
		d = scan.nextDouble();
		System.out.println(kareK�k(d));
	}
}