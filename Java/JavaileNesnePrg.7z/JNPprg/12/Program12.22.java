package metotlar;

import java.util.Scanner;

class StringToInt {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.println("Bir tamsay� giriniz :");
		String aString = scan.nextLine();

		int aInt = Integer.parseInt(aString);
		System.out.println(aInt);
	}
}