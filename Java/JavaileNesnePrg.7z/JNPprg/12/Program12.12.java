package metotlar;

class Demo {
	static double a = 32.14;
	static double b = 27.96;

	public static void main(String[] args) {
		System.out.println(Topla(a, b));
	}

	static double Topla(double x, double y) {
		return x + y;
	}
}