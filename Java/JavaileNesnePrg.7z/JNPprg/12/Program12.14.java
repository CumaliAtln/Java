package metotlar;

import java.util.Scanner;

class SquareRoot {
	static double d;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Karek�k� al�nacak say�y� giriniz: ");
		d = scan.nextDouble();

		System.out.println(Math.sqrt(d));
	}
}