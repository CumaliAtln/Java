package metotlar;

import java.util.Scanner;

public class Demo {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        double x, y;
        String sx, sy;
        System.out.println("L�tfen birinci say�y� giriniz : ");
        //sx = scan.nextLine();
        x = scan.nextDouble();

        System.out.println("L�tfen ikinci say�y� giriniz : ");
        //sy = scan.nextLine();
        y = scan.nextDouble();

        System.out.println();

        System.out.printf("%n Ba�l�ca Math Metotlar� :");
        System.out.printf("%n abs(%f) = %f", x, Math.abs(x));
        System.out.printf("%n ceiling(%f) = %f", x, Math.ceil(x));
        System.out.printf("%n exp(%f) = %f", x, Math.exp(x));
        System.out.printf("%n floor(%f) = %f", x, Math.floor(x));
        System.out.printf("%n IEEERemainder(%f,%f) = %f", x, y, (x % y));

        System.out.println();
        System.out.printf("%n log(%f) = %f", x, Math.log(x));
        System.out.printf("%n log10(%f) = %f", x, Math.log10(x));
        System.out.printf("%n max(%f) = %f", x, Math.max(x, y));
        System.out.printf("%n min(%f,%f) = {2}", x, y, Math.min(x, y));
        System.out.printf("%n pow(%f)  = %f", x, Math.pow(x, y));
        System.out.printf("%n round(%f) = %d", x, Math.round(x));
        //System.out.printf("%n sign(%f)  = %f", x, Math.sign(x));
        System.out.printf("%n sqrt(%f)  = %f", x, Math.sqrt(x));
        System.out.println();
        System.out.printf("%n cos(%f)   = %f", x, Math.cos(x));
        System.out.printf("%n sin(%f)   = %f", x, Math.sin(x));
        System.out.printf("%n tan(%f)   = %f", x, Math.tan(x));
        System.out.printf("%n cotan(%f) = %f ", x, 1 / Math.tan(x));
        System.out.println();
        System.out.printf("%n acos(%f)  = %f", x, Math.acos(x));
        System.out.printf("%n asin(%f)  = %f ", x, Math.asin(x));
        System.out.printf("%n atan(%f)  = %f ", x, Math.atan(x));
        System.out.printf("%n atan2(%f,%f) = {2}", x, y, Math.atan2(x, y));
        System.out.println();
        System.out.printf("%n cosh(%f)  = %f ", x, Math.cosh(x));
        System.out.printf("%n sinh(%f)  = %f ", x, Math.sinh(x));
        System.out.printf("%n tanh(%f)  = %f ", x, Math.tanh(x));
        System.out.printf("%n cotanh(%f) = %f ", x, 1 / Math.tanh(x));
    }
}