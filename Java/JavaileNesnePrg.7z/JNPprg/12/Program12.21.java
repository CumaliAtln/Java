import java.util.Scanner;

class Demo {
	static int n, m, r, ebob;

	/* a ve b ebob'i bulunacak say�lar */
	static int ebobBul(int a, int b) {
		int c;
		while (a % b != 0) {
			c = a % b;
			a = b;
			b = c;
		}
		return b;
	}

	public static void main(String[] args) {
	    
	    System.out.println("EBOB i bulunacak �� say� giriniz.");
		Scanner scan = new Scanner(System.in);

		System.out.println("Birinci say� :");
		n = scan.nextInt();

		System.out.println("�kinci say� :");
		m = scan.nextInt();

		System.out.println("���nc� say� :");
		r = scan.nextInt();

		System.out.println(ebobBul(ebobBul(n, m), r));
	}
}