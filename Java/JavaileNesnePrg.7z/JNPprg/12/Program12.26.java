public class Demo {
	
	final double INCH   = 2.54;
	double   enCM, enINCH  = 8.5;
	double boyCM, boyINCH  = 11;

	public static void main(String[] args) {

		Demo d = new Demo();
		d.enCM = d.enINCH* d.INCH;
		d.boyCM = d.boyINCH*d.INCH;
		System.out.printf("A4 ka��d�n eni %f inc, boyu %f inch  \n", d.enINCH, d.boyINCH);
		System.out.printf("A4 ka��d�n eni %f cm, boyu %f  cm  \n ", d.enCM,  d.boyCM);	 
	}
}