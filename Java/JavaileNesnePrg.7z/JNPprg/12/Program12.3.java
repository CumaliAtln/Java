package metotlar;

import java.util.Date;

public class Demo {

    public static void main(String[] args) {
        TarihYaz();
    }

    void TarihYaz() {
        Date date = new Date();
        System.out.println(date.toString());
    }
}