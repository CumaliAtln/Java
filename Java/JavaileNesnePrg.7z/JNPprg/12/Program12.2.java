package metotlar;

import java.util.Scanner;

public class KarakterleriSay {

    static int n;
    static char[] sArr;

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Bir sat�r yaz�p Enter'e bas�n�z: ");
        String s = scan.nextLine();
        sArr = s.toCharArray();

        System.out.println("K���k Harf Say�s� : " + k���kHarfSay(sArr));
        System.out.println("B�y�k Harf Say�s� : " + b�y�kHarfSay(sArr));
        System.out.println("Rakam Say�s� : " + rakamSay(sArr));
        System.out.println("Alfasay�sal Olmayan Karakter Say�s� :" + alfasay�salDe�ilseSay(sArr));
    }

    static int k���kHarfSay(char[] str) {
        int k���kHarfSay�s� = 0;
        for (char harf : str) {
            if (Character.isLowerCase(harf)) {
                k���kHarfSay�s�++;
            }
        }
        return k���kHarfSay�s�;
    }

    static int b�y�kHarfSay(char[] str) {
        int b�y�kHarfSay�s� = 0;
        for (char harf : str) {
            if (Character.isUpperCase(harf)) {
                b�y�kHarfSay�s�++;
            }
        }
        return b�y�kHarfSay�s�;
    }

    static int rakamSay(char[] str) {
        int rakamSay�s� = 0;
        for (char harf : str) {
            if (Character.isDigit(harf)) {
                rakamSay�s�++;
            }
        }
        return rakamSay�s�;
    }

    static int alfasay�salDe�ilseSay(char[] str) {
        int alfaSay�salDe�ilSay�s� = 0;
        for (char harf : str) {
            if (!Character.isLetterOrDigit(harf)) {
                alfaSay�salDe�ilSay�s�++;
            }
        }
        return alfaSay�salDe�ilSay�s�;
    }
}
