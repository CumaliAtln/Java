public class Daire {
    static final double PI = 3.14159;
    short yar��ap;
    static double daireninAlan�;

    double alanBul(int r) {
        int y�ap = r;
        daireninAlan� = PI * y�ap * y�ap;
        return daireninAlan�;
        }

     public static void main(String[] args) {
     Daire d1 = new Daire();
     daireninAlan� = d1.alanBul(3);
     System.out.println(daireninAlan�);
     System.out.println(Daire.daireninAlan�);

     System.out.println();

     Daire d2 = new Daire();
     daireninAlan� = d2.alanBul(5);
     System.out.println(daireninAlan�);
     System.out.println(Daire.daireninAlan�);
     }
}