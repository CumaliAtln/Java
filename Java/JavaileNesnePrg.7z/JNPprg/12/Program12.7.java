public class MathMetotlari {

  public static void main(String[] args) {
    
    int i = 5;
    int j = -7;
    double x = 53.8;
    double y = 1.72;
  
    System.out.printf("i = %d",  i); 
    System.out.printf("j = %d",  j); 
    System.out.printf("x = %f",  x); 
    System.out.printf("y = %f",  y); 

    System.out.printf("%n Math.abs(%d) = %d ", i,Math.abs(i));     
    System.out.printf("%n Math.abs(%d) = %d ", i,Math.abs(j));
    System.out.printf("%n Math.abs(%f) = %f ", x,Math.abs(x));     
    System.out.printf("%n Math.abs(%f) = %f ", y,Math.abs(y)); 
    
    System.out.printf("%n Math.round(%f) = ", x,Math.round(x)); 
    System.out.printf("%n Math.round(%f) = ", y,Math.round(y)); 
    
    System.out.printf("%n ceil(%d) = %f" , i, Math.ceil(i));  
    System.out.printf("%n ceil(%d) = %f" , j, Math.ceil(j));  
    System.out.printf("%n ceil(%f) = %f" , x, Math.ceil(x));  
    System.out.printf("%n ceil(%f) = %f" , y, Math.ceil(y));  


    System.out.printf("%n Math.floor(%d) = %f" , i, Math.floor(i));  
    System.out.printf("%n Math.floor(%d) = %f" , j, Math.floor(j));  
    System.out.printf("%n Math.floor(%f) = %f" , x, Math.floor(x));  
    System.out.printf("%n Math.floor(%f) = %f" , y, Math.floor(y));  
 
   System.out.printf("%n Math.min(%d,%d) = %d " ,i,j, Math.min(i,j));  
   System.out.printf("%n Math.min(%f,%f) = %f " ,x,y, Math.min(x,y)); 
   System.out.printf("%n Math.min(%d,%f) = %f " ,i,x, Math.min(i,x)); 
   System.out.printf("%n Math.min(%d,%f) = %f " ,j,y, Math.min(j,y)); 
   
   System.out.printf("%n Math.max(%d,%d) = %d " ,i,j, Math.max(i,j));  
   System.out.printf("%n Math.max(%f,%f) = %f " ,x,y, Math.max(x,y)); 
   System.out.printf("%n Math.max(%d,%f) = %f " ,i,x, Math.max(i,x)); 
   System.out.printf("%n Math.max(%d,%f) = %f " ,i,y, Math.max(i,y)); 
   
    
      
     System.out.printf("%n Math.PI = %f ", Math.PI);     
     System.out.printf("%n Math.E  = %f ", Math.E);       

    double a�� = 45.0 * 2.0 * Math.PI/360.0;
    System.out.printf("%n cos(a��) = %f ", a��, Math.cos(a��));     
    System.out.printf("%n sin(a��) = %f)", a��, Math.sin(a��));     
      
    double kesir = 0.707;

    System.out.printf("%n acos(kesir) = %f ",kesir, Math.acos(kesir));     
    System.out.printf("%n asin(kesir) = %f ",kesir, Math.asin(kesir));     
    System.out.printf("%n atan(kesir) = %f ",kesir, Math.atan(kesir));     
  
    System.out.printf("%n exp(1.0)  = " + Math.exp(1.0));
    System.out.printf("%n exp(10.0) = " + Math.exp(10.0));
    System.out.printf("%n exp(0.0)  = " + Math.exp(0.0));

    System.out.printf("%n log(1.0)    = "    + Math.log(1.0));
    System.out.printf("%n log(10.0)   = "   + Math.log(10.0));
    System.out.printf("%n log(Math.E) = " + Math.log(Math.E));

    System.out.printf("%n pow(2.0, 2.0)  = " + Math.pow(2.0,2.0));
    System.out.printf("%n pow(10.0, 3.5) = " + Math.pow(10.0,3.5));
    System.out.printf("%n pow(8, -1)     = " + Math.pow(8,-1));

    System.out.println();
    for (i=0; i < 10; i++) {
      System.out.printf(
       "%d say�s�n�n kare k�k� = %f %n",  i, Math.sqrt(i));
    }
    
    System.out.println("Se�kisiz (random) say�: " + Math.random());     
    System.out.println("Se�kisiz ba�ka (random) say�: " + Math.random());
  }
}