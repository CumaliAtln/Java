package metotlar;

import java.util.Date;

public class Tarih {

    public static void main(String[] args) {
			Tarih t = new Tarih();
      t.TarihYaz();
    }

    void TarihYaz() {
        Date date = new Date();
        System.out.println(date.toString());
    }
}