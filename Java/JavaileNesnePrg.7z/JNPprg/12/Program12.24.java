public class Demo {
	static double PI = 3.1415;
	double yar��ap;

	public Demo(double yar��ap) {
		this.yar��ap = yar��ap;
	}

	public double alan() {
		return yar��ap * yar��ap * PI;
	}

	public static double piDe�i�tir(double yeniPI) {
		PI = yeniPI;
		return PI;
	}

	public static void main(String[] args) {
		Demo d = new Demo(3);
		
		System.out.println("ilk   PI  = " + PI);
		System.out.println("ilk alan  = " + d.alan());
		
		piDe�i�tir(7.678);
		
		System.out.println("yeni PI   = " + PI);
		System.out.println("yeni alan = " + d.alan());
	}
}