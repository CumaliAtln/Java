package metotlar;

import java.util.Scanner;

class EKOK2 {
	static int n, m, ekok;

	/* a ve b ekok'u bulunacak say�lar */
	static int ekokBul(int a, int b) {
		int prod;
		if (b % a == 0)
			return b;
		else {
			prod = a * b;
			while (a != b) {
				if (a > b)
					a = a - b;
				else
					b = b - a;
			}
			return ekokBul(b, prod / a);
		}
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("ekok 'u bulunacak say�lar�n ilkini giriniz:");
		n = scan.nextInt();

		System.out.println("ekok 'u bulunacak say�lar�n ikincisini giriniz:");
		m = scan.nextInt();

		System.out.println(ekokBul(n, m));
	}
}