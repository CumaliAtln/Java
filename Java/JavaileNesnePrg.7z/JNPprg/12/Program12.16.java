package metotlar;

import java.util.Scanner;

class LogaritmaBul2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Logaritmas� al�nacak say�y� giriniz: ");
		System.out.println(Math.log(scan.nextDouble()));
	}
}