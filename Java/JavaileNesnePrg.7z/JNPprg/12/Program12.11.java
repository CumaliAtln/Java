package metotlar;

public class WhileD�ng�s� {
	public static void main(String[] args) {
		System.out.println(WhileContinue());
		WhileBreak();
		doWhile();
	}

	static int WhileContinue() {
		int a = 0;
		while (a < 10) {
			a++;
			if (a == 5) {
				a++;
				continue;
			}
		}
		return a;
	}

	static void WhileBreak() {
		int a = 0;
		while (a < 10) {
			a++;
			if (a == 5)

				break;
		}
		System.out.println(a);
	}

	static void doWhile() {
		int a = 0;

		while (a < 40) {
			if (a == 27)
				break;
			a++;
		}
		System.out.println(a);
	}
}