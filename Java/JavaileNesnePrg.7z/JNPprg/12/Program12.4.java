package metotlar;

import java.util.Date;

public class Tarih {

    public static void main(String[] args) {
      t.TarihYaz();
    }

    static void TarihYaz() {
        Date date = new Date();
        System.out.println(date.toString());
    }
}