import java.util.Scanner;

class Demo {
	static int n, m, ebob;

	/* a ve b ebob'i bulunacak say�lar */
	static int ebobBul(int a, int b) {
		int c;
		while (a % b != 0) {
			c = a % b;
			a = b;
			b = c;
		}
		return b;
	}