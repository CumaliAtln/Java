public class Demo {

	public static void main(String[] args) {

		final double INCH  = 2.54;
		double   enCM, enINCH  = 8.5;
		double boyCM, boyINCH  = 11;
		enCM = enINCH* INCH;
		boyCM = boyINCH*INCH;
		System.out.printf("A4 ka��d�n eni %f inc, boyu %f inch  \n", enINCH, boyINCH);
		System.out.printf("A4 ka��d�n eni %f cm, boyu %f  cm  \n ", enCM,  boyCM);	 
	}
}