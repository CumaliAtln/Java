public class Hata01 {

	public static void main(String[] args) {

		int payda = 0;
		int pay = 38 / payda;
	}
}