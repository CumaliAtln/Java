// Bu program hata i�erdi�i i�in derlenemez.
class Demo {
	static void throwBir() {
		System.out.println("Inside throwBir.");
		throw new IllegalAccessException("demo");
	}

	public static void main(String args[]) {
		throwBir();
	}
}