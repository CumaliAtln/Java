	class Hata03 {
	
	public static void main(String args[]) {
		int d, a;

		try { // denenecek blok.
			d = 0;
			a = 38 / d;
			System.out.println("Bu sat�r yaz�lmaz.");
		} 
		 // s�f�ra b�lme hatas�n� yakala
		catch (ArithmeticException e) { 
			System.out.println("S�f�ra b�lme hatas�.");
		}
		System.out.println("catch blokundan sonraki kodlar.");
	}
}