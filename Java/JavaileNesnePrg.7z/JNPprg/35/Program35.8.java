// ��i�e try deyimleri.
class Hata08 {
	public static void main(String args[]) {
		try {
			int a = args.length;

			/*
			 * Sat�r komutundan parametre girilmezse a�a��daki atama s�f�ra
			 * b�lme hatas� yarat�r.
			 */
			int b = 72 / a; // s�f�ra b�lme hatas�

			System.out.println("a = " + a);

			try { // i�i�e try bloklar�
				/*
				 * Sat�r komutundan tek parametre girilirse a�a��daki deyim
				 * s�f�ra b�lme hatas� yarat�r.
				 */
				if (a == 1)
					a = a / (a - a); // s�f�ra b�lme hatas�

				/*
				 * Komut sat�r�ndan iki parametre girilirse a�a��daki deyim
				 * out-of-bounds yarat�r.
				 */
				if (a == 2) {
					int c[] = { 7 };
					c[23] = 56; // out-of-bounds hatas�
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("Array indisini a�ar : " + e);
			}

		} catch (ArithmeticException e) {
			System.out.println("0 ile b�lme: " + e);
		}
	}
}