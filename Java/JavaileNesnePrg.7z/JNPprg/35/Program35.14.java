// finally i�in demo.
class Demo {
	// metot d���nda exception
	static void procA() {
		try {
			System.out.println("procA i�inde");
			throw new RuntimeException("demo");
		} finally {
			System.out.println("procA's finally");
		}
	}

	// Bir try blokundan geri d�n
	static void procB() {
		try {
			System.out.println("procB i�inde");
			return;
		} finally {
			System.out.println("procB'deki finally");
		}
	}

	// Bir try blokunu normal i�le.
	static void procC() {
		try {
			System.out.println("procC i�inde");
		} finally {
			System.out.println("procC'deki finally");
		}
	}

	public static void main(String args[]) {
		try {
			procA();
		} catch (Exception e) {
			System.out.println("Exception yakalan�yor");
		}
		procB();
		procC();
	}
}