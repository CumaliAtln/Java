/* 
 * Belli belirsiz i�i�e try bloklar�
 */
class Hata09 {
	static void nesttry(int a) {
		try { // i�-i�e try bloku
			/*
			 * Tek parametre girilirse a�a��daki deyim 
			 * divide-by-zero exception
			 * olu�turur.
			 */
			if (a == 1)
				a = a / (a - a); // division by zero

			/*
			 * �ki parametre girilirse array indis s�n�r� a��l�r, 
			 * out-of-bounds exception olu�ur.
			 */
			if (a == 2) {
				int c[] = { 1 };
				c[38] = 99; // out-of-bounds exception olu�ma yeri
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Array indis s�n�r� a��l�yor : " + e);
		}
	}

	public static void main(String args[]) {
		try {
			int a = args.length;

			/*
			 * Hi� args de�eri yoksa divide-by-zero exception olu�ur.
			 */
			int b = 38 / a;

			System.out.println("a = " + a);

			nesttry(a);
		} catch (ArithmeticException e) {
			System.out.println("0 ile b�lme: " + e);
		}
	}
}
