// Bu program do�rudur, derlenebilir.
class Demo {
	static void throwBir() throws IllegalAccessException {
		System.out.println("throwBir i�inde.");
		throw new IllegalAccessException("demo");
	}

	public static void main(String args[]) {
		try {
			throwBir();
		} catch (IllegalAccessException e) {
			System.out.println("Yakalan�yor ... " + e);
		}
	}
}