public class Demo {
	public static void main(String Args[]) {
		int[] array = new int[3];
		try {
			for (int i = 0; i < 4; ++i) {
				array[i] = i;
			}
			System.out.println(array);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("�ok gittin, geri d�n!");
		} finally {
			System.out.println("Bu kadar�  yeter.");
		}
	}
}