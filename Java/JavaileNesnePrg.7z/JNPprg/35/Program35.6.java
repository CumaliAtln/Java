			// �oklu catch deyimleri.
	class Hata06 {
	public static void main(String args[]) {

		try {
			int a = args.length;
			System.out.println("a = " + a);
			int b = 57 / a;
			int c[] = { 3 };
			c[47] = 39;
		} catch (ArithmeticException e) {
			System.out.println("0 ile b�lme : " + e);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index oob: " + e);
		}
		System.out.println("try/catch blokundan sonraki kodlar.");
	}
}