import java.util.Random;

class Hata04 {
	public static void main(String args[]) {
		int a = 0, b = 0, c = 0;
		Random r = new Random();

		for (int i = 0; i < 22000; i++) {
			try {
				b = r.nextInt();
				c = r.nextInt();
				a = 56789 / (b / c);
			} catch (ArithmeticException e) {
				System.out.println("S�f�ra b�lme hatas�.");
				a = 0; // devam etmek i�in 0 atand�
			}
			System.out.println("a: " + a);
		}
	}
}