// throw.
class ThrowDemo {
	static void demoyap() {
		try {
			throw new NullPointerException("demo");
		} catch (NullPointerException e) {
			System.out.println("hata, demoyap i�inde yakaland�.");
			throw e; // hata tekrar at�l�yor
		}
	}

	public static void main(String args[]) {
		try {
			demoyap();
		} catch (NullPointerException e) {
			System.out.println("Tekrar yakalan�yor: " + e);
		}
	}
}