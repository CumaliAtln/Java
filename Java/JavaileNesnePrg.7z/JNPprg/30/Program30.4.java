import java.awt.*;

public class Demo extends Panel
{
   public static void main(String [] args)
   {
      Frame f = new Frame("Frame B");

      Demo ex = new Demo();

      f.add("Center", ex);

      f.pack();
      f.show();
   }
}