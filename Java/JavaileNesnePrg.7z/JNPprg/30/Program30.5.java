import java.awt.*;
import java.awt.event.*;

public class FrameC extends Frame {
    private Yokedici alet;
    
    FrameC () {
        alet = new Yokedici ();
        setTitle ("Frame C");
        setSize (300,120);
        addWindowListener (alet);
        show ();
    }

    public static void main (String args[]) {
        Frame f;
        f = new FrameC ();
    }
}
					
class Yokedici extends WindowAdapter {
    public void windowClosing (WindowEvent event) {
        System.exit (0);
    }
}