import java.awt.*;
import java.awt.event.*;
import java.io.*;

class Editor extends Frame implements ActionListener
{
    TextArea textArea = new TextArea();

    Editor()
    {
    super("Text AWT Editor");
        setLayout(new BorderLayout());
        add("Center", textArea);
        Menu menu = new Menu("Dosya");
        menu.add(makeMenuItem("A�"));
        menu.add(makeMenuItem("Kaydet"));
        menu.add(makeMenuItem("��k"));
        MenuBar menuBar = new MenuBar();
        menuBar.add(menu);
        setMenuBar(menuBar);
        pack();
    }
    private MenuItem makeMenuItem(String name)
    {
        MenuItem m = new MenuItem(name);
        m.addActionListener(this);
        return m;
    }
    public static void main(String[] s)
    {
        new Editor().show();
    }