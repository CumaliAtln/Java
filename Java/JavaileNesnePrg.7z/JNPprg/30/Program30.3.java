import java.awt.*;

public class Demo
{
   public static void main(String [] args)
   {
      Frame f = new Frame("Frame A");

      f.show();  //deprecated
   }
}