import java.awt.*;
import java.awt.event.*;

public class BasitWindow extends Frame
{
    public static final int WIDTH = 300; 
    public static final int HEIGHT = 200;

     public static void main(String[] args)
    {
        BasitWindow basitWindow = new BasitWindow();
        basitWindow.setSize(WIDTH, HEIGHT);

        WindowDestroyer listener = new WindowDestroyer();
        basitWindow.addWindowListener(listener);

        basitWindow.setVisible(true);
    }

    public void paint(Graphics g)
    {
        g.drawString("Kapatmak i�in x d��mesine bas�n�z!", 75, 100); 
    }
}

 class WindowDestroyer extends WindowAdapter
{
    public   void windowClosing(WindowEvent e) 
    {
        System.exit(0);
    }
}