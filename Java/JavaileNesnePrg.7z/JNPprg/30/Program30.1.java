import java.awt.*;

class AFrame extends Frame{

    public static void main(String[] args){

      AFrame frame = new AFrame();
      frame.setSize(200, 200); 
      frame.setVisible(true);
    }
}