import java.awt.*;


class AFrame{

    public static void main(String[] args){

      Frame aFrame = new Frame();
        aFrame.setSize(200, 200); 
        aFrame.setVisible(true);
     }
}