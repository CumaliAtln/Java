import java.io.*;

public class DosyayaYaz{
  public static void main(String[] args)throws IOException{
  Writer output = null;
  String text = "Ne dil yeter seni anlatmaya!";
  File file = new File("hedef.txt");
  output = new BufferedWriter(new FileWriter(file));
  output.write(text);
  output.close();
  System.out.println("Dosyaya yaz�ld�");  
  }
}