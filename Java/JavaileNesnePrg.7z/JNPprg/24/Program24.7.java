import java.io.FileReader;

public class DosyaOkuma {
    public static void main(String[] argv) throws Exception {
        FileReader fr = new FileReader("c:/Jprg/Deneme.txt");
        int count;
        char chrs[] = new char[80];

        do {
            count = fr.read(chrs);
            for (int i = 0; i < count; i++)
                System.out.print(chrs[i]);
        } while (count != -1);
    }
}