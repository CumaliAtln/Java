import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class KarekterKopyala {
    public static void main(String[] args) throws IOException {
        FileReader giri� = null;
        FileWriter ��k�� = null;

        try {
            giri� = new FileReader("mca.txt");
            ��k�� = new FileWriter("gitAnday.txt");

            int c;
            while ((c = giri�.read()) != -1) {
                ��k��.write(c);
            }
        } finally {
            if (giri� != null) {
                giri�.close();
            }
            if (��k�� != null) {
                ��k��.close();
            }
        }
    }
}