import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TextDosyaOku {

    public static void main(String[] args) {
        File file = new File("c:/Jprg/Veysel.txt");
        StringBuffer contents = new StringBuffer();
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(file));
            String text = null;
            // sat�r sonuna kadar tekrarla
            while ((text = reader.readLine()) != null) {
                contents.append(text)
                .append(System.getProperty("line.separator"));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // Dosta i�eri�ini g�ster
        System.out.println(contents.toString()); 
    }
}

/** 
Okunan �rnek text dosyas�:  c:/Jprg/Veysel.txt

DOSTLAR BEN� HATIRLASIN - A�IK VEYSEL

Ben giderim ad�m kal�r,
Dostlar beni hat�rlas�n.
D���n olur, bayram gelir,
Dostlar beni hat�rlas�n.

Can bedenden ayr�lacak,
T�tmez baca, yanmaz ocak,
Selam olsun kucak kucak,
Dostlar beni hat�rlas�n.

A�ar solar t�rl� �i�ek
Kimler g�lm��, kim g�lecek
Murat yalan, �l�m ger�ek,
Dostlar beni hat�rlas�n.

G�n ikindi ak�am olur,
G�r ki ba�a neler gelir,
Veysel gider, ad� kal�r
Dostlar beni hat�rlas�n

*/