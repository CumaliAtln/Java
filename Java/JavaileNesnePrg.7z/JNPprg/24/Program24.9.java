package javaio;
/*
 * BinOITest.java program�
 * binary dosya yazar ve onu okur 
*/
import java.io.*;

class Demo {
	public static void main(String[] args) throws IOException {
		DataOutputStream out = new DataOutputStream(new FileOutputStream(
				"binDosya"));
		double x = 1.0;
		int count = 10;
		out.writeInt(count);
		for (int i = 0; i < count; i++) {
			out.writeDouble(x);
			x = x / 9.0;
		}
		out.close();
		DataInputStream in = new DataInputStream(
				new FileInputStream("binDosya"));
		count = in.readInt();
		for (int i = 0; i < count; i++) {
			System.out.println(in.readDouble());
		}
	}
}