/**
	DEFNE ORMANI 

	K�le sahipleri ekmek kaygusu �ekmedikleri
	i�in felsefe yap�yorlard�, ��nk�
	Ekmeklerini k�leler veriyordu onlara;
	K�leler ekmek kaygusu �ekmedikleri i�in
	Felsefe yapm�yorlard�, ��nk� ekmeklerini
	k�le sahipleri veriyordu onlara ...
                  ---Melih Cevdet Anday---
*/									

		
\begin{prg} \label{javaio:ByteKopyala} \end{prg}
\begin{lstlisting}		
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteKopyala {
    public static void main(String[] args) throws IOException {
        FileInputStream in = null;
        FileOutputStream out = null;
        try {
            in = new FileInputStream("defne.txt");
            out = new FileOutputStream("outDefne.txt");
            int c;

            while ((c = in.read()) != -1) {
                out.write(c);
            }

        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
    }
}