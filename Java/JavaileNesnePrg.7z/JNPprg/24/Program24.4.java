import java.io.*;
class NumberTest
{
	public static void main (String[] args) throws IOException
	{
		BufferedReader stdin = new BufferedReader ( new InputStreamReader( System.in ) );

		String str;
		int num;

		System.out.println("Bir tam say� giriniz : ");
		str = stdin.readLine();
		num = Integer.parseInt( str ); // str, ilgili s�n�fa g�m�l�yor

		if ( num < 0 )  // beklenen dallanma
		{
	      System.out.println(  num + " say�s� negatiftir");
		}
		else   // beklenmeyen dallanma
		{
		   System.out.println( num + " say�s� pozitiftir");
		}
		System.out.println("Son");
	}
}