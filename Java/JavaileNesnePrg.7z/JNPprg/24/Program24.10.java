import java.io.*;

public class DataInputOutputStreamDemo {
    public static void main(String[] args) throws IOException {
        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(
                    new FileOutputStream("c:/Jprg/Data.txt")));
        out.writeDouble(3.14159);
        out.writeUTF("Bu PI say�s�d�r.");
        out.writeDouble(1.41413);
        out.writeUTF("2'nin karek�k�d�r.");
        out.close();
        DataInputStream in = new DataInputStream(new BufferedInputStream(
                    new FileInputStream("Data.txt")));
        System.out.println(in.readDouble());
        System.out.println(in.readUTF());
        System.out.println(in.readDouble());
        System.out.println(in.readUTF());
    }
}