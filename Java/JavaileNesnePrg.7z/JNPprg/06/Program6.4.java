public class Demo {

	public static void main(String args[]) throws IOException {

		System.out.println(7*3);
		System.out.println('7' * '3');
		}
	}