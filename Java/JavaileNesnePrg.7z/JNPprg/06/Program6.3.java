public class Demo {

	public static void main(String[] args) {

		String str = "0123456789";

		for (int i = 0; i < str.length(); i++)
			System.out.print("`\t"' + str.charAt(i) + " rakam�n�n ASCII kodu "
					+ (int) str.charAt(i));
	}
}