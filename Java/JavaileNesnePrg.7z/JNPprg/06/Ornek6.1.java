public class Demo {

	public static void main(String[] args) {

		Character ch1 = new Character('A');
		System.out.println(ch1);
	}
}