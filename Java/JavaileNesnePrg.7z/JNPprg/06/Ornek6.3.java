import java.io.*;

public class Demo {

	public static void main(String args[]) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		System.out.println("Bir karekter giriniz:");
		String str = read.readLine();
		char ch = str.charAt(0);

		System.out.println(Character.isLetterOrDigit(ch));
		System.out.println(Character.isWhitespace(ch));

		System.out.println(Character.isLetter(ch));
		System.out.println(Character.isDigit(ch));

		System.out.println(Character.isUpperCase(ch));
		System.out.println(Character.isLowerCase(ch));
	}
}