import java.io.*;

public class Demo {

	public static void main(String args[]) throws IOException {

		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		System.out.println("Bir karekter giriniz:");
		String str = read.readLine();
		char ch    = str.charAt(0);

		System.out.println(Character.toUpperCase(ch));
		System.out.println(Character.toLowerCase(ch));
		
		System.out.println(Character.toString(ch));
		System.out.println(Character.toTitleCase(ch));
	}
}