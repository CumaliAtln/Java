import java.io.*;
//import java.lang.*;

public class Demo {

	public static void main(String args[]) throws IOException {
		BufferedReader buff = new BufferedReader(new InputStreamReader(
				System.in));
		System.out.println("Bir karekter giriniz:");
		String str = buff.readLine();
		for (int i = 0; i < str.length(); ++i) {
			char c = str.charAt(i);
			int j = (int) c;
			System.out.println(c + " nin ASCII kodu = " + j + " dir.");
		}
	}
}