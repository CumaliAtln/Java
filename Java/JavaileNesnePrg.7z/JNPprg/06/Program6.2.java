public class Demo {

	public static void main(String[] args) {

		String str = "ABCDEFG�HI�JKLMNO�PRS�TU�VYZ";

		for (int i = 0; i < str.length(); i++)
			System.out.println(str.charAt(i) + " harfinin ASCII kodu "
					+ (int) str.charAt(i));
	}
}