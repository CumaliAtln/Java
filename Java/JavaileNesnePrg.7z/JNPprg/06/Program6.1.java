	public class Demo {
	
		public static void main(String[] args) {
	
			System.out.println((int)'K');
			System.out.println((char)75);
	}
}