public class Demo {

	public static void main(String[] args) {

		Character ch = new Character('8');
		System.out.print("ch 'n�n karekter de�eri = ");
		System.out.println(ch.charValue());
	}
}