import java.io.*;
import java.lang.*;

public class Demo {
	public static void main(String args[]) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		System.out.println("Bir karekter giriniz:");
		String s = read.readLine();
		char c = s.charAt(0);
		
		System.out.println(Character.isLetter(c));
		System.out.println(Character.isDigit(c));
		
		System.out.println(Character.isUpperCase(c));
		System.out.println(Character.isLowerCase(c));

		System.out.println(Character.toLowerCase(c));
		System.out.println(Character.toUpperCase(c));
		
		System.out.println(Character.getType(c));
		System.out.println(Character.getNumericValue(c));
		
		System.out.println(Character.toChars(c));
		System.out.println(Character.valueOf(c));
		
		public class Demo {

	    public static void main(String[] args)
	    {
	    	int n1 = Character.getNumericValue('\u0041');
	    	System.out.println(n1);
	}
}