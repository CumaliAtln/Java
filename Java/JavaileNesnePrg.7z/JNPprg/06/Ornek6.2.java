public class Demo {

	public static void main(String[] args) {

		for (int i=48; i<58;i++){
			char ch = (char) i ;
		System.out.print ("\t" + ch);}
	}
}