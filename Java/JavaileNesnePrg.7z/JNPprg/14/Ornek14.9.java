public class Demo {

	public static void main(String[] args) {

		int toplam = 0;

		for (int i = 100; i >= 0; i = i - 5) {
			toplam = toplam + i;
		}
		System.out.println(toplam);
	}
}