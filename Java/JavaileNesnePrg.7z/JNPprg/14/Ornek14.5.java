public class Demo {

	public static void main(String[] args) {
		int n = 1, toplam = 0;
		do {
			toplam += n;
			n++;
		} while (n <= 100);
		System.out.println("100 e kadar tamsay�lar�n toplam� = " + toplam);
	}
}