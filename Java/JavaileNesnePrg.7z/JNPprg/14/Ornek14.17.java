public class Demo {

	public static void main(String[] args) {
		int i = 0;
		String[] kent = { "Ankara", "Van", "Hakkari", "Trabzon" };
		do {
			System.out.println(kent[i]);
			i++;
		} while (i < kent.length);
	}
}