public class Demo {

	public static void main(String[] args) {
		int say� = 1;
		do {
			System.out.print ("\t" + say�);
			say�++;
		} while (say� <= 10);
	}
}