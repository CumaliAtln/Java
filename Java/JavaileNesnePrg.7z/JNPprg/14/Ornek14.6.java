public class Demo {

	public static void main(String[] args) {
		String str = "Bu metindeki ilk r harfinin yerini bul.";
        StringBuffer sonMetin = new StringBuffer();

        int i = 0;
        char c = str.charAt(i);

        do {
            sonMetin.append(c);
						c = str.charAt(++i);
        } while (c != 'r');
        System.out.println(i);
    }
}