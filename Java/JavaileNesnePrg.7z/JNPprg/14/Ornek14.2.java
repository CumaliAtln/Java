public class Demo {

	public static void main(String[] args) {

		int n = 10, faktoriyel = 1;
		while (n >= 1) {
			faktoriyel *= n;
			n--;
		}
		System.out.println("10! = " + faktoryel);
	}
}