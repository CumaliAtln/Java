public class Demo {

	public static void main(String[] args) {
		int i = 0;
		String[] kent = { "Ankara", "Van", "Hakkari", "Trabzon" };
		while (i < kent.length) {
			System.out.println(kent[i]);
			i++;
		}
	}
