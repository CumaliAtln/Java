public class Demo {

    public static void main(String[] args) {
        /**
         * say� de�i�keni
         * int tipi bir de�i�kendir.
         */
        int say�; 		   // Yaz�lacak say�lar� tutacak de�i�ken
        say� = 1; 		   // de�i�kene verilen ilk de�er
        while (say� < 6) { 	   // mant�ksal deyim
            System.out.println(say�);
            say� = say� + 1;   // say�ya 1 ekle
        }
        System.out.println("Son");
    }
}