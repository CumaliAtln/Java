public class Demo {

	public static void main(String[] args) {

		String[] kent = { "Ankara", "Van", "Hakkari", "Trabzon" };
		for (String s : kent) {
			System.out.println(s);
		}
	}
}