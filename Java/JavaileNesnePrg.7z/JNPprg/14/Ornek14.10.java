public class Demo {

	static int i;

	public static void main(String[] args) {

		int toplam = 0;

		for (i = 1000; i >= 0; i = i - 100) {
			toplam = toplam + i;
		}
		System.out.println(toplam);
	}
}