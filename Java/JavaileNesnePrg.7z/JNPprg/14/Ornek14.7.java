public class Demo {

	public static void main(String[] args) {

		int toplam = 0;

		for (int i = 1; i <= 100; i++) {
			toplam = toplam + i;
		}
		System.out.println(toplam);
	}
}