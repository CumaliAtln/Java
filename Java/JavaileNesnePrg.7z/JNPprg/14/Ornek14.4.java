public class Demo {

	public static void main(String[] args) {

		int say� = 1;
		while (say� <= 10) {
			System.out.print("\t" + say�);
			say�++;
		}
	}
}