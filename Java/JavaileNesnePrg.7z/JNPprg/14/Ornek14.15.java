public class Demo {

	public static void main(String[] args) {

		String[] kent = { "Ankara", "Van", "Hakkari", "Trabzon" };
		for (int i = 0; i < kent.length; i++) {
			System.out.println(kent[i]);
		}
	}
}