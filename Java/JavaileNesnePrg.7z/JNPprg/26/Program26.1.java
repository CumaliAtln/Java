/**
 * Bu program zaman� her saniyede 
 * bir kez ekrana yazar 
 * @author Anonim
 */

import java.awt.*;
import java.util.*;

public class Saat extends javax.swing.JApplet {

    /**
     * Color nesnesi yarat
     * Yaz�lar�n rengi i�in
     * alt�nSar�s� se�
     * @ alt�nSar�s�  yaz�lar�n rengidir
     */
    private Color alt�nSar�s� = new Color(255, 204, 102);
    private String sonZaman = "";

    public void init() {
        /**
         * appletin zemin rengi
         * @ black  appletin zemin rengidir
         * */
        setBackground(Color.black);
    }

    //Appleti g�ster 
    public void paint(Graphics screen) {

        Graphics2D screen2D = (Graphics2D)screen;
        /**
         * Font se�
         * @ Font.BOLD  yaz�lar i�in font
         */
        Font type = new Font("Normal", Font.BOLD, 20);
        screen2D.setFont(type);
        /**
         * GregorianCalender nesnesi yarat
         * Bu takvim d�nyan�n g�ne� etraf�ndaki
         * hareketine en iyi uyum sa�layan takvimdir
         * @ day  GregorianCalendar nesnesinin referans�  
         */
        GregorianCalendar day = new GregorianCalendar();
        /**
        @ getTime() �imdiki zaman� verir
        @ toString() zaman� yazar
        @ time �imdiki zaman� tutan de�i�ken
         */
        String time = day.getTime().toString();

        screen2D.setColor(Color.black);
        screen2D.drawString(sonZaman, 5, 25);
        screen2D.setColor(alt�nSar�s�);
        screen2D.drawString(time, 5, 25);

        // Thread.sleep(1000) 1 sn bekletir
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e) {
            // bir �ey yapma
        }
        // zaman� ata
        sonZaman = time;
        // zaman� tekrar yaz
        repaint();
    }
}