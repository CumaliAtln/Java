import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringToDate {

    public static void main(String[] args) {

        DateFormat df = new SimpleDateFormat("dd/MMMM/yyyy");

        try {
            Date today = df.parse("23/N�SAN/1920");
            System.out.println("Tarih = " + df.format(today));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}