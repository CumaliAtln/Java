import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalendarDemo {

    public static void main(String[] args) {

        Calendar gCal = GregorianCalendar.getInstance (  ) ; 
       gCal.set (  1920, 3, 23  ) ; 
        System.out.println ( gCal.getTime (  )  ) ;
    }
}