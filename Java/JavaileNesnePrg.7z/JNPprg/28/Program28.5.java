import java.util.Date;

public class Demo {

    public static void main(String[] args) {

        Date date = new Date();

        System.out.printf("ta  : %ta %n", date);
        System.out.printf("tA  : %tA %n", date);

        System.out.printf("tb  : %tb %n", date);
        System.out.printf("tB  : %tB %n", date);

        System.out.printf("tc  : %ta %n", date);
        System.out.printf("tC  : %tC %n", date);

        System.out.printf("td  : %td %n", date);
        System.out.printf("te  : %te %n", date);

        System.out.printf("ty  : %ty %n", date);	
        System.out.printf("tY  : %tY %n", date);	

        System.out.printf("tl  : %tl %n", date);
        System.out.printf("tm  : %tm %n", date);

        System.out.printf("tM  : %tM %n", date);
        System.out.printf("tp  : %tp %n", date);

        System.out.printf("tD  : %tD %n", date);
    }
}