import java.util.*;
import java.text.*;

public class Language {

    public static void main(String[] args) {
        Locale trLocale = new Locale("tr", "TR");
        System.out.println("�ntan�ml� (default) Dil : " + trLocale.getDisplayLanguage());
    }
}