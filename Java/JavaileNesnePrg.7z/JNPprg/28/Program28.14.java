import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

class StringToDate {
    public static void main(String[] args) {

		try {
			Date date1;
			date1 = new SimpleDateFormat("MM/dd/yy").parse("05/01/05");
			System.out.println(date1);
			Date date2 = new SimpleDateFormat("dd-MMM-yyyy").parse("19-May-2012");
			System.out.println(date2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}