import java.text.SimpleDateFormat;
import java.util.Date;

public class SimpleDateFormat1{

    public static void main(String args[]){

        // Date nesnesi yarat
        Date date = new Date();
        // �stenen tarih bi�emini belirle
        String DATE_FORMAT = "dd/MM/yyyy";
        /**
        SimpleDateFormat nesnesi yarat ve 
        belirledi�in tarih format�n� ona ver.
         */
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        /*
        SimpleDateFormat s�n�f�n�n format metodunu kullan
        */
        System.out.println("Bu g�n�n tarihi : " + sdf.format(date) );
    }
}