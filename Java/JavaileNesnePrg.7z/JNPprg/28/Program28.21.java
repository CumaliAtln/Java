import java.util.Scanner;

public class Art�kY�l {

	public static int hangiSene;

	public static boolean art�kSeneBul(int y�l) {
		if (y�l % 400 == 0)
			return true;
		else if (y�l % 100 == 0)
			return false;
		else if (y�l % 4 == 0)
			return true;
		else
			return false;
	}

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		/**
		 * Konsoldan bir tamsay� oku ve onu hangiSene de�i�kenine ata
		 */
		System.out.println("Hangi sene?  ");
		hangiSene = in.nextInt();
		in.close();
		// Art�kseneBul(hangiSene);

		System.out.println(hangiSene + " Art�k y�l m�? :"
				+ art�kSeneBul(hangiSene));
	}
}