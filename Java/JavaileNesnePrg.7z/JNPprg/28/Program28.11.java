import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CumhuriyetBayram� {
  public static void main(String[] argv) throws Exception {

    Calendar bayram = new GregorianCalendar(1923, Calendar.OCTOBER, 29); 
    Date date =  bayram.getTime();
    System.out.println(date);
  }
}