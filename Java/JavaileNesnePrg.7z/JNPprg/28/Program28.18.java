import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TarihToString {

    // milisaniye cinsinden tarihi bir tarih nak���na d�n��t�r
    private void calcDate(long milisaniye) {
        SimpleDateFormat date_format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        Date tarih = new Date(milisaniye);
        System.out.println(date_format.format(tarih));
    }

    private void tarihYaz(){
        Calendar cal = new GregorianCalendar();
        Date creationDate = cal.getTime();
        SimpleDateFormat date_format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        System.out.println(date_format.format(creationDate));
    }

    public static void main(String[] args) {
        TarihToString convert = new TarihToString ();
        convert.calcDate(System.currentTimeMillis());
        convert.tarihYaz();
    }
}