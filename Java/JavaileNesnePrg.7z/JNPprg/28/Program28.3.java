import java.util.Locale;
public class Yereller{
    public static void main(String[] args) {
        Locale[] s = Locale.getAvailableLocales();
        System.out.println("Desteklenen Y�reseller: ");
        for (int i=0; i<s.length; i++) {
            System.out.println("   "+s[i].getLanguage()+", "
                +s[i].getCountry()+", "+s[i].getVariant()+", "
                +s[i].getDisplayName());
        }
    }
}