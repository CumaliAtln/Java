import java.text.DateFormat;
import java.util.Date;

public class DateFormat1 {

    public static void main(String[] args) {
        /**
         * Yeni bir Date nesnesi yarat. 
         * Nesne �imdiki zaman� i�erir. 
         */
        Date �imdi = new Date();
        //  toString() ile yaz
        System.out.println(" 1. " + �imdi.toString());
        // default DateFormat bi�emi
        System.out.println(" 2. " + DateFormat.getInstance().format(�imdi));
        // default time bi�emi
        System.out.println(" 3. " + DateFormat.getTimeInstance().format(�imdi));
        // default date-time bi�emi        
        System.out.println(" 4. " +
            DateFormat.getDateTimeInstance().format(�imdi));
        /**
         *  default time'in
         *k�sa, orta ve uzun bi�emleri
         */ 
        System.out.println(" 5. " +
            DateFormat.getTimeInstance(DateFormat.SHORT).format(�imdi));
        System.out.println(" 6. " +
            DateFormat.getTimeInstance(DateFormat.MEDIUM).format(�imdi));
        System.out.println(" 7. " +
            DateFormat.getTimeInstance(DateFormat.LONG).format(�imdi));
        /**
         *  default date-time i�in
         *  date ve time bi�emleri i�in 
         *  ayr� ayr� uzunluk belirlenebilir
         */
        System.out.println(" 8. " + DateFormat.getDateTimeInstance(
                DateFormat.SHORT, DateFormat.SHORT).format(�imdi));
        System.out.println(" 9. " + DateFormat.getDateTimeInstance(
                DateFormat.MEDIUM, DateFormat.SHORT).format(�imdi));
        System.out.println("10. " + DateFormat.getDateTimeInstance(
                DateFormat.LONG, DateFormat.LONG).format(�imdi));
    }
}