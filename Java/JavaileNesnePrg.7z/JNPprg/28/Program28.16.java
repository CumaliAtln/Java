import java.util.*;
import java.text.*;

public class Tarih {

    public static void main(String[] args) {
		
		
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy", new Locale("tr"));
        String date = sdf.format(new Date());
        System.out.println(date);
    }
}