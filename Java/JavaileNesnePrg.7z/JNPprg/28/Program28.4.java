import java.util.*;

public class Date1{

    public static void main(String args[]){
        /*
        G�n�n tarihini ve zaman� yazar
        */
        Date date = new Date();
        System.out.println(date);
    }
}