import java.util.Date;
import java.util.GregorianCalendar;

public class GregorianCalendar1 {
    public static void main(String[] a) {
        
        GregorianCalendar gc = new GregorianCalendar();
        Date �imdi = gc.getTime();
        System.out.println(�imdi);
    }
}