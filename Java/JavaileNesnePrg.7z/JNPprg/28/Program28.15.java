import java.text.SimpleDateFormat;
import java.util.Date;

public class SimpleDateFormat2 {

    public static void main(String[] args) {

        SimpleDateFormat formatter = new SimpleDateFormat("yy");  // 02
        Date date = new Date();
        String s = formatter.format(date);
        System.out.println(s);

        formatter = new SimpleDateFormat("yyyy");  // 2002
        Date date2 = new Date();
        String s2 = formatter.format(date2);
        System.out.println(s2);
    }
}