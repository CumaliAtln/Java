import java.applet.Applet;
import java.awt.*;

public class RadioButton extends Applet {
    private TextField t;
    private Font f;
    private CheckboxGroup radio;
    private Checkbox radioBold, radioItalic,
    radioPlain;

    public void init()
    {
        t = new TextField( "Bu metnin yaz� tipini de�i�tir. ", 40 );
        radio = new CheckboxGroup(); 
        add( t );   // textfield ekle
        add( radioPlain = new Checkbox( "Normal", radio, true ) );
        add( radioItalic = new Checkbox( "Italic", radio, false ) );  
        add( radioBold = new Checkbox( "Koyu", radio, false ) );
    }

    public boolean action( Event e, Object o )
    {
        int style;

        if ( e.target instanceof Checkbox) {

            if ( radioPlain.getState() == true  )  
                style = Font.PLAIN;
            else if ( radioItalic.getState() == true )
                style = Font.ITALIC;
            else
                style = Font.BOLD;  

            f = new Font( "TimesRoman", style, 14 );
            t.setFont( f );
        }
        return true;
    }
}