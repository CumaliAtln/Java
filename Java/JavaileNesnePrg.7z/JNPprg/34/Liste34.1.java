import java.applet.*;
import java.awt.*;

public class Demo01 extends Applet {

    public void init() {
    }

    public void stop() {
    }

    public void paint(Graphics g) {
        g.drawString("Hey gidi d�nya,", 20, 20);
        g.drawString("heeey!", 20, 40);

    }
}