import java.awt.Graphics;
import javax.swing.*;

public class KareKokApplet extends JApplet {

    double kareKok;
    int x;

    public void init() {
        String num1;
        num1 = JOptionPane.showInputDialog("Say�y� giriniz: ");

        x= Integer.parseInt(num1); // string'den tamsay�ya d�n���m
        kareKok = Math.sqrt(x);
    }

    public void paint(Graphics g) {
        g.drawString(x + " say�s�n�n kare k�k� = " + kareKok, 30,30);
    }
}