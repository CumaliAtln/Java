<html> 
  <applet code=Demo01.class width=100 height=100> 
  </applet> 
</html> 