<html> 
  <applet code=RadioButton.class width=100 height=100> 
  </applet> 
</html> 