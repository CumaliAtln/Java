<HTML>
<TITLE>RootApplet</TITLE> 
<BODY>
  <applet code="KareKokApplet.class" height=100 width=300>
  </applet>
</BODY>
</HTML>