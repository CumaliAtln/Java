import java.util.Scanner;

public class Vergi01 {
    public static void main(String[] args) {
        double br�t;
        Scanner in = new Scanner(System.in); 
        System.out.println("Br�t Geliri giriniz :"); 
        br�t = in.nextDouble();
        in.close();
        System.out.println("Gelir Vergisi :"); 
        System.out.println(br�t * 40 / 100);
    }
}