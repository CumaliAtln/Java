import java.util.Scanner;

public class Vergi03 {
    static double br�tGelir;

    static double br�tGelirGir() {
        Scanner scan = new Scanner(System.in); 
        System.out.println("Br�t Geliri giriniz :"); 
        br�tGelir = scan.nextDouble();
        scan.close();
        return br�tGelir;
    }

    static double vergiHesapla() {
        return br�tGelirGir() * 40 / 100;
    }

    static void vergiYaz() { 
        System.out.println(vergiHesapla()); 
    }

    public static void main(String[] args) {
        vergiYaz();
    }
}