import java.util.Scanner;

public class Vergi04 {
    static double br�tGelir;

    double br�tGelirGir() {
        Scanner scan = new Scanner(System.in); 
        System.out.println("Br�t Geliri giriniz :"); 
        br�tGelir = scan.nextDouble();
        scan.close();
        return br�tGelir;
    }

    double vergiHesapla() {
        return br�tGelirGir() * 40 / 100;
    }

    void vergiYaz() { System.out.println(vergiHesapla()); 
    }

    public static void main(String[] args) {
        Vergi04 vrg = new Vergi04();
        vrg.vergiYaz();
    }
}