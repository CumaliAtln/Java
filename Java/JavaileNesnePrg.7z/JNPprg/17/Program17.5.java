import java.util.Scanner;

public class Vergi05 {
    double brut;

    double br�tGelirGir() {
        Scanner s = new Scanner(System.in); 
        System.out.println("Br�t Geliri giriniz : "); 
        brut = s.nextDouble();
        return (brut);
    }

    double vergiHesapla() {
        return br�tGelirGir() * 40 / 100;
    }

    void vergiYaz() {
        System.out.println(vergiHesapla());
    }

    public static void main(String[] args) {

        Vergi05 p = new Vergi05(); 
        System.out.println("p nesnesi i�in :"); 
        p.vergiYaz();

        System.out.println();

        Vergi05 q = new Vergi05(); 
        System.out.println("q nesnesi i�in :"); 
        q.vergiYaz();	}
}