import java.util.Scanner;

public class Vergi06 {

    static double br�tGelirGir() {
        Scanner s = new Scanner(System.in); System.out.println("Br�t Geliri giriniz :"); return (s.nextDouble());
    }

    static double vergiHesapla() {
        return br�tGelirGir() * 40 / 100;
    }

    static void vergiYaz() {

        System.out.println(vergiHesapla());
    }

    public static void main(String[] args) {

        Vergi06 vrg = new Vergi06();
        vrg.vergiYaz();
    }
}