public class IntegerExample {

    public static void main(String[] args) {
        /**
         * int tipi Integer s�n�f�na sarmalayan kurucu
         */
        Integer intNesneA = new Integer(123);

        /**
         * String'e d�n��m�� int tipi Integer s�n�f�na sarmalayan kurucu
         */
        Integer intNesneB = new Integer("123");

        System.out.println(intNesneA);
        System.out.println(intNesneB);
    }
}