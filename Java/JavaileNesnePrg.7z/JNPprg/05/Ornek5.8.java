public class Demo {

    public static void main(String[] args){

        double dd = 420.5;
        int i = dd;

        System.out.println(i);
    }        
}