public class IntegerExample {

    public static void main(String[] args) {
        int n = 123;
        Integer nObj =  new Integer(n);   
        System.out.println(Integer.signum(n));
        System.out.println(Integer.toBinaryString(n));
        System.out.println(Integer.toHexString(n));
        System.out.println(Integer.toOctalString(n));
        System.out.println(nObj.toString());
        System.out.println(Integer.toString(n));
        System.out.println(Integer.toString(n,4));
    }
}