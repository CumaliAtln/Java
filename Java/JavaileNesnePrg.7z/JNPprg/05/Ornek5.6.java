public class Demo {

	public static void main(String[] args) {

		float ff;
		double dd = 1.234567890123456789;
		ff =  (float) dd;
		System.out.println(ff);
	}
}