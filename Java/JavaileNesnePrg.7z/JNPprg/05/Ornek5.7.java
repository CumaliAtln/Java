public class Demo {

	public static void main(String[] args) {

		float ff = 5.6789f;
		float toplam;
		toplam = 3.0 + ff;
		System.out.println(toplam);
	}
}