public class Demo {

	public static void main(String[] args) {

		float ff = 2.5678f;
		double dd;
		dd =   ff;
		System.out.println(dd);
	}
}