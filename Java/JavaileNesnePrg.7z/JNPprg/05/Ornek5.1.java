public class Demo {

	public static void main(String[] args) {

	      int   n = 120;
	      float x;
        x  = a;
		System.out.println(x);
	}
} 