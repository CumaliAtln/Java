public class Demo {

	public static void main(String[] args) {

		int n;
		float ff = 3.8644f;
		n = ff;
		System.out.println(ff);
	}
} 