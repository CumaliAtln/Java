import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int n;
		Scanner in = new Scanner(System.in);
		System.out.println("Bir tamsay� giriniz: ");
		n = in.nextInt();
		in.close();

		if (n > 0) // if y�nlendirmesi
			System.out.printf("Girdi�iniz %d say�s� pozitiftir. ", n);
	}
}