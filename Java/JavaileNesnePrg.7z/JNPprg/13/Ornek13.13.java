public class Demo {

	public static void main(String[] args) {

		int x = 1;
		if (x-- > x)
			System.out.println("Ankara");
		else
			System.out.println(" �stanbul");
	}
}