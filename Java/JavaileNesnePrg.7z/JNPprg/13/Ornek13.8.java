import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int ay;
		int y�l;
		int g�nSay�s� = 0;
		Scanner scan = new Scanner(System.in);
		System.out.println("Hangi y�l ?	");
		y�l = scan.nextInt();

		System.out.println("Hangi ay ?	");
		ay = scan.nextInt();

		switch (ay) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			g�nSay�s� = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			g�nSay�s� = 30;
			break;
		case 2:
			if (((y�l % 4 == 0) && !(y�l % 100 == 0)) || (y�l % 400 == 0))
				g�nSay�s� = 29;

			else

				g�nSay�s� = 28;

			break;
		default:
			System.out.println("Ge�ersiz ay");
			break;
		}
		System.out.println("G�n say�s� = " + g�nSay�s�);
	}
}