import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int i;
		Scanner scan = new Scanner(System.in);
		System.out.println("Bir tamsay� giriniz ");
		i = scan.nextInt();

		if (i % 3 == 0)
			System.out.printf("%d tamsay�s� 3 ile tam b�l�n�r. ", i);
		else if (i % 2 == 0)
			System.out.printf("%d tamsay�s� �itf say�d�r. ", i);
		else
			System.out.printf(
					"%d tamsay�s� tek say�d�r, ama 3 ile tam b�l�nmez. ", i);
	}
}