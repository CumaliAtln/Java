public class Zaman {

		public static  String zamanHesapla(long zaman) {
		    String unit = "milisaniye";
		    if (zaman >= 365*24*60*60*1000L) {
		        unit = "y�l";
		        zaman /= 365*24*60*60*1000L;
		    } else if (zaman >= 24*60*60*1000) {
		        unit = "g�n";
		        zaman /= 24*60*60*1000;
		    } else if (zaman >= 60*60*1000) {
		        unit = "saat";
		        zaman /= 60*60*1000;
		    } else if (zaman >= 60*1000) {
		        unit = "dakika";
		        zaman /= 60*1000;
		    } else if (zaman >= 1000) {
		        unit = "saniye";
		        zaman /= 1000;
		    }
		    return zaman + " " + unit;
		}
		public static void main(String[] args) {
			System.out.println(zamanHesapla(1234567890));
		}
}