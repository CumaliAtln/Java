import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String ad, ileti;

		System.out.println("Ad�n�z nedir? ");
		ad = scan.nextLine();

		switch (ad) {
		case "Lefter":
			ileti = "Efsane futbolcumuz, de�il mi?";
			break;
		case "Arda":
			ileti = "�yi bir golc�m�z!";
			break;
		case "Servet":
			ileti = "�yi bir savunma oyuncumuz!";
			break;
		case "R��t�":
			ileti = "�yi bir kalecimizdi.";
			break;
		default:
			ileti = "Volkan'a gelince, kafas� yerine ellerini kulland���nda harika bir kaleci!";
			break;
		}// switch sonu

		System.out.println();
		System.out.println(ileti);
		System.out.println();
	}
}