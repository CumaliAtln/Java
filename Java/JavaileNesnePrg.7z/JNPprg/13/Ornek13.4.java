public class Demo {

	public static void main(String[] args) {
		String kent = "Ankara";
		if (kent == "Ankara") {
			System.out.println("Ankara ba�kenttir.");
		}
	}
}