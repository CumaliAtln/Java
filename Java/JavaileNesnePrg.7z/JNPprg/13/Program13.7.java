public class Demo {

	public static void main(String[] args) {

		double d = Math.random();
		System.out.println(d);
		if ((int) (d * 100) % 2 == 0) {
			System.out.println("Say� �ifttir.");
		} else {
			System.out.println("Say� tektir.");
		}
	}
}