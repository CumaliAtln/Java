	public class Demo {

	public static void main(String[] args) {

		int a = 5, b = 10, c = 1;
		if (a + b > c)
			System.out.println(a + b);
		else
			System.out.println(c);
	}
}