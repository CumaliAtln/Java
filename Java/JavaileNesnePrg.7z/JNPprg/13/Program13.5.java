import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int i;
		Scanner scan = new Scanner(System.in);
		System.out.println("Not ortalaman�z� giriniz : ");
		i = scan.nextInt();

		if (i > 90)
			System.out.printf("Puan�n�z %d ise notunuz A	olur. ", i);
		else if (i > 75)
			System.out.printf("Puan�n�z %d ise notunuz B	olur. ", i);
		else if (i > 60)
			System.out.printf("Puan�n�z %d ise notunuz C	olur. ", i);
		else if (i > 50)
			System.out.printf("Puan�n�z %d ise notunuz D	olur. ", i);
		else
			System.out.printf("Puan�n�z %d ise notunuz F	olur. ", i);
	}
}