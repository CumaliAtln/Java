import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int i;
		Scanner scan = new Scanner(System.in);
		System.out.println("Bug�n �s� ka� derecedir? ");
		i = scan.nextInt();

		if (i < 10)
			System.out.println("Bug�n hava so�uktur. ");
		else if (i < 20)
			System.out.println("Bug�n hava serindir. ");
		else
			System.out.println("Bug�n hava s�cakt�r. ");
	}
}