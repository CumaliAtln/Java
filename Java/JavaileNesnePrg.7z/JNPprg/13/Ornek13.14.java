	public class Demo {

	public static void main(String[] args) {

	    if(.001==0.1f)
	    	System.out.println("Arda");
	    else if(0.123 == 0.123f)
	    	System.out.println("Ronaldinho");
	    else
	    	System.out.println("Lefter");
	}
}