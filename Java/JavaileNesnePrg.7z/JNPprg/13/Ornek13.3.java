public class Test {
   public static void main(String args[]){
      int x = 10;

      if( x < 20 ){
         System.out.print("Bu bir if deyimidir.");
      }
   }
}