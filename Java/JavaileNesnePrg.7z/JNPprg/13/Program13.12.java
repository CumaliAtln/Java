import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int a, b, c;
		int durum = -1;

		Scanner scan = new Scanner(System.in);
		System.out.println("�� tamsay� giriniz :");
		a = scan.nextInt();
		b = scan.nextInt();
		c = scan.nextInt();

		if (a > b && a > c) {
			durum = 1;
		} else if (b > c) {
			durum = 2;
		} else {
			durum = 3;
		}
		switch (durum) {
		case 1:
			System.out.println("Say�lar�n en b�y��� = " + a);
			break;
		case 2:
			System.out.println("Say�lar�n en b�y��� = " + b);
			break;
		case 3:
			System.out.println("Say�lar�n en b�y��� = " + c);
			break;
		default:
			System.out.println("Belirlenemedi!");
		}
	}
}