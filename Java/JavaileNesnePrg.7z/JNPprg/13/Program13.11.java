import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int n;

		Scanner scan = new Scanner(System.in);
		System.out.println("Hangi �ikolata : 1=K���k 2=Orta 3=B�y�k");
		n = scan.nextInt();

		int bedel = 0;
		switch (n) {
		case 1:
			bedel += 250;
			break;
		case 2:
			bedel += 500;
			break;
		case 3:
			bedel += 750;
			break;

		default:
			System.out
					.println("Ge�ersiz se�im yapt�n�z. L�tfen 1, 2, 3 say�lar�ndan birisini se�iniz.");
			break;
		}
		if (bedel != 0)
			System.out.printf("L�tfen %d TL at�n�z. %n", bedel);
		System.out.println("Afiyet olsun! Gene bekleriz!");
	}
}