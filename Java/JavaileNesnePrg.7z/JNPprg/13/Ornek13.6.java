public class Demo {

	public static void main(String[] args) {

		if (1)
			System.out.println("Yanl�� boolean.");
	}
}