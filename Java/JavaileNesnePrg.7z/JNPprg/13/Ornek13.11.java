public class Demo {

	public static void main(String[] args) {
		int a = 5;

		boolean b = (3 > 2) ? (3 > a) : (3 < a);
		System.out.println(b);

		if (3 > 2)
			b = (3 > a);
		else
			b = (3 < a);
		System.out.println(b);
	}
}