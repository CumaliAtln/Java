import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Not ortalaman�z nedir?");
		int puan = scan.nextInt();

		switch (puan / 10) {
		case 10:
			System.out.println("Notunuz A	d�r. ");
			break;
		case 9:
			System.out.println("Notunuz A-	d�r. ");
			break;
		case 8:
			System.out.println("Notunuz B+	dir. ");
			break;
		case 7:
			System.out.println("Notunuz B 	dir. ");
			break;
		case 6:
			System.out.println("Notunuz B-	dir. ");
			break;
		case 5:
			System.out.println("Notunuz C+	dir. ");
			break;
		case 4:
			System.out.println("Notunuz C	dir. ");
			break;
		case 3:
			System.out.println("Notunuz C-	dir. ");
			break;
		case 2:
			System.out.println("Notunuz D+	dir. ");
			break;
		case 1:
			System.out.println("Notunuz D	dir. ");
			break;
		case 0:
			System.out.println("Notunuz F	dir. ");
			break;
		default:
			System.out.println("Yanl�� not girdiniz! ");
			break;
		}
	}
}