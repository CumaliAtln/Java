{
	System.out.print("�stanbul bir metropold�r.");
	System.out.println(25);
}