public class Demo {

	public static void main(String[] args) {

		int n = 5, toplam = 30;
		int ortalama = (n > 0) ? sum / n : 0;
		System.out.println(ortalama);

		if (n > 0)
			ortalama = toplam / n;
		else
			ortalama = 0;
		System.out.println(ortalama);
	}
}