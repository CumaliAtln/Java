import java.io.IOException;
import java.lang.Character;

public class Demo {

	public static void main(String[] args) {

		char ch;
		int inChar = 0;

		System.out.println("Karne notunuzu giriniz :");

		try {
			inChar = System.in.read();
		} catch (IOException e) {
			System.out.println("Giri� hatas�");
		}

		ch = (char) inChar;
		switch (Character.toUpperCase(ch)) {
		case 'A':
			System.out.println("Pekiyi");
			break;

		case 'B':
			System.out.println("�yi");
			break;

		case 'C':
			System.out.println("Orta");
			break;

		case 'D':
			System.out.println("Hmmmm....");
			break;

		case 'F':
			System.out.println("Daha iyisini ba�arabilirsin!");
			break;

		default:
			System.out.println("Ba�ar� notunu yanl�� girdiniz!");
			break;
		}
	}
}
