import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Haftan�n ka��nc� g�n� :");

		int day = scan.nextInt();
		switch (day) {
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
			System.out.println("�al��maya git!");
			break;
		case 7:
			System.out.println("Cumartesi, yar�m g�n tatil");
			break;
		case 1:
			System.out.println("Pazar, dinlen!");
			break;
		default:
			System.out.println("Yanl�� g�n girdiniz!");
		}
	}
}