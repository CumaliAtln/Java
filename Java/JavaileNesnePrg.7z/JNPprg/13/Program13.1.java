import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		int i;
		Scanner scan = new Scanner(System.in);
		System.out.println("Bir tamsay� giriniz: ");
		i = scan.nextInt();

		if (i > 0)
			System.out.printf("Girdi�iniz %d say�s� pozitiftir ", i);
		else
			System.out.printf("Girdi�iniz %d say�s� pozitif de�ildir ", i);
	}
}