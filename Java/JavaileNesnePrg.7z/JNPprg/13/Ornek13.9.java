public class Demo {

	public static void main(String[] args) {

		int i = 17, j = 21;
		System.out.println((i < j ? i : j));  
	}
}