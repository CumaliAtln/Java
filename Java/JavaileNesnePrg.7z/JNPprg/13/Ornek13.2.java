public class Demo {

	public static void main(String[] args) {
		int x = 10, y = 20;
		{
			System.out.println("Takastan �nce :");
			System.out.printf("x = %d ; y = %d \n ", x, y);
			int z; 	// blok i�inde kullan�lacak yerel de�i�ken
			z = x;
			x = y;
			y = z;
		}
		System.out.println("Takastan sonra :");
		System.out.printf("x = %d ; y = %d ", x, y);
	}
}