import java.io.IOException;

public class Demo {

	public static void main(String[] args) {

		char c;
		int inChar = 0;

		System.out.println("Bir tu�a bas�n�z :");

		try {
			inChar = System.in.read();
		} catch (IOException e) {
			System.out.println("Giri� hatas�");
		}

		c = (char) inChar;
		if (Character.isUpperCase(c))
			System.out.println("B�y�k harf girdiniz.");
		else if (Character.isLowerCase(c))
			System.out.println("K���k harf girdiniz.");
		else if (Character.isDigit(c))
			System.out.println("Bir rakam girdiniz.");
		else
			System.out.println("Alfasay�sal olmayan bir karekter girdiniz.");
	}
}