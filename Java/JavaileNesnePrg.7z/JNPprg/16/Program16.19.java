	class Daire7 {
		static int yar��ap; 
		static double �evre; 
		static double alan; 
		final static double pi = 3.14;
	
			// Kurucu metodunun tan�m�
		public Daire7( int r ){
				yar��ap = r ;
			};
	
		public static void main (String args[]) {
	
		Daire7 d1 = new Daire7(7);	//Birinci nesneyi yarat�yor
		D1.alan    = pi * yar��ap * yar��ap; 
		D1.�evre   = 2 * pi * yar��ap; 
	
		System.out.println ("ilk Dairenin Yar��api : " + d1.yar��ap); 
		System.out.println ("ilk Dairenin Alan�    : " + d1.alan); 
		System.out.println ("ilk Dairenin �evresi  : " + d1.�evre); 
		System.out.println();
	
		Daire7 d2 = new Daire7(9);	//�kinci nesneyi yarat�yor
		d2.alan = pi * yar��ap * yar��ap; 
		d2.�evre = 2 * pi * yar��ap; 
	
	System.out.println ("ikinci Dairenin Yar��api : " + d1.yar��ap);
		System.out.println ("ikinci Dairenin Alan�    : " + d2.alan); 
		System.out.println ("ikinci Dairenin �evresi  : " + d2.�evre); 
		System.out.println();
			
		System.out.println ("ilk Dairenin Yar��api : " + d1.yar��ap); 
		System.out.println ("ilk Dairenin Alan�    : " + d1.alan); 
		System.out.println ("ilk Dairenin �evresi  : " + d1.�evre); 
	System.out.println();
	} 	
}