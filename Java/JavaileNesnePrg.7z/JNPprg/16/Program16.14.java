	class Daire2 {
			static int 		yar��ap; 
			static double 	�evre; 
			static double 	alan; 
			final static double PI = 3.14;
	
		public static void main (String args[]) {
		
			yar��ap = 4;
			alan = PI * yar��ap * yar��ap; 
			�evre = 2 * PI * yar��ap; 
	
			System.out.println ("Dairenin Alan�   : " + alan); 
			System.out.println ("Dairenin �evresi : " + �evre); 
	} 	
}