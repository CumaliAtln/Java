class ToplamaD {
	int m, n, toplam;

	public ToplamaD(int a, int b) {
		m = a;
		n = b;
	};

	public static void main(String[] args) {

		ToplamaD tD = new ToplamaD(9, 2);
		tD.toplam = tD.m + tD.n;

		System.out.println(tD.toplam);
	}
}