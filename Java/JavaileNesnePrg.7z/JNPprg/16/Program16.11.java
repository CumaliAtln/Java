class ToplamaF {
	int n, m, toplam;

	public ToplamF(int a, int b) {
		m = a;
		n = b;
		toplam = m + n;
		System.out.println(toplam);
	};

	public static void main(String[] args) {

		ToplamaF tF = new ToplamaF(11, 5);
	}
}