class Daire8 {
    int yar��ap; 
    double �evre; 
    double alan; 
    final static double pi = 3.14;

    double alanBul(){
        alan = pi * yar��ap * yar��ap ;
        return alan ;
    };

    double �evreBul(){
        return 2 * pi * yar��ap ;
    };

    // kurucu metodu
    public Daire8(int rad){
        yar��ap=rad;
    }

    public static void main (String args[]) {

        Daire8 c1 = new Daire8(7);	// nesne yarat�l�yor
        System.out.println ("ilk Dairenin Yar��api : " + c1.yar��ap);  	
        System.out.println("ilk Dairenin Alan�     : " + c1.alanBul());
        System.out.println("ilk Dairenin Alan�     : " + c1.�evreBul());
        System.out.println();

        Daire8 c2 = new Daire8(9);	// nesne yarat�l�yor
        System.out.println("ikinci Dairenin Yar��api: " + c2.yar��ap);   			
        System.out.println("ikinci Dairenin Alan�   : " + c2.alanBul());
        System.out.println("ikinci Dairenin �evresi : " + c2.�evreBul());
        System.out.println();		

        System.out.println ("ilk Dairenin Yar��api : " + c1.yar��ap);  			
        System.out.println("ilk Dairenin Alan�     : " + c1.alanBul());
        System.out.println("ilk Dairenin Alan�     : " + c1.�evreBul());
        System.out.println();

    } 	
}