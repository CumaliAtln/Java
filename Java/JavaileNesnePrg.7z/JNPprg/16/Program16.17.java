	class Daire5 {
			static int yar��ap; 
			static double �evre; 
			static double alan; 
			final static double pi = 3.14;
			
		public static void main (String args[]) {
		
			// �ntan�ml� kurucu ile nesne yarat�lm�yor 
			yar��ap = 7;
			alan = pi * yar��ap * yar��ap; 
			�evre = 2 * pi * yar��ap; 
	
			System.out.println ("Dairenin Alan�   : " + alan); 
			System.out.println ("Dairenin �evresi : " + �evre); 
	} 	
}