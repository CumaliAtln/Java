class Daire4 {

		static int yar��ap; 
		static double �evre; 
		static double alan; 
		final static double PI = 3.14;
		
  public static void main (String args[]) {
	
		// �ntan�ml� kurucu nesne yarat�yor 
	Daire4 d = new Daire4();  		
		yar��ap = 7;
		alan    = PI * yar��ap * yar��ap; 
		�evre   = 2 * PI * yar��ap; 

		System.out.println ("Dairenin Alan�   : " + alan); 
		System.out.println ("Dairenin �evresi : " + �evre); 
	} 	
}