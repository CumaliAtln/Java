class Toplama2 {

    public static void main(String[] args) {
        int m = 3;
        int n = 5;
        System.out.println(m+n);
    }
}