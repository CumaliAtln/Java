public class Havuz
{
    //Anl�k de�i�kenler
    private float havuzBoyu ;
    private float havuzEni ;
    private float minDerinlik;
    private float maxDerinlik;

    //�imdi bir kurucu metodu yazal�m.
    Havuz ( float uzunluk, float en, float  azDerinlik, float  cokDerinlik) 	
    {
        havuzBoyu 	= uzunluk;
        havuzEni 	  = en;
        minDerinlik	= azDerinlik;
        maxDerinlik	= cokDerinlik;
    }

    public static void main(String[] args){
        Havuz h1 = new Havuz ( 100.0f , 30.0f , 3.0f , 8.0f ) ;
        System.out.printf("%f %f %f %f %n", h1.havuzBoyu, h1.havuzEni, h1.minDerinlik, h1.maxDerinlik); 
    }
}