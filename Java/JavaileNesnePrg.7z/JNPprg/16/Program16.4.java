class Toplama4 {
    static int m;
    static int n;
    static int toplam;

    public static void main(String[] args) {

        m= 3;
        n= 5;

        System.out.println(m+n);
    }
}