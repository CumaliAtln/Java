class ToplamaA {
 int m, n, toplam;
	
 public static void main(String[] args) {
		
	ToplamaA tA = new ToplamaA();
	tA.m=3;
	tA.n=5;
	tA.toplam = tA.m + tA.n;
		
	System.out.println(tA.toplam);
	}
}