class ToplamaE {
    int m, n, toplam;

    public ToplamaE(int a, int b) {
        m = a;
        n = b;
        toplam = m+n;
    };

    public static void main(String[] args) {

        ToplamaE tE = new ToplamaE(9, 2);
				System.out.println(toplam);
    }
}