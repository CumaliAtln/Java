public class ToplamaB {
	int n, m, toplam;
	public ToplamaB() {
	};
	
	public static void main(String[] args) {
		
			ToplamaB tB = new ToplamaB();
			tB.m = 7;
			tB.n = 15;
			tB.toplam = tB.m + tB.n;
			
			System.out.println(tB.toplam);
	}
}