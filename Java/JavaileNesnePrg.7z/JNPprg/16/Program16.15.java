	class Daire3 {
	
			static int yar��ap; 
			static double �evre; 
			static double alan; 
			final static double PI = 3.14;
			
		public static void main (String args[]) {
		
			// �ntan�ml� kurucu ile nesne yarat�l�yor
		Daire3 d = new Daire3();  		
			d.yar��ap = 7;
			d.alan = PI * d.yar��ap * d.yar��ap; 
			d.�evre = 2 * PI * d.yar��ap; 
	
			System.out.println ("Dairenin Alan�   : " + d.alan); 
			System.out.println ("Dairenin �evresi : " + d.�evre); 
	} 	
}