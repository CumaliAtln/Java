	class Daire10 {
    int yar��ap; 
    double �evre; 
    double alan; 
    final static double pi = 3.14;

    // Yazd�rma metodunun tan�m�
    void yaz(Daire10 d){
        System.out.println ("Dairenin Yar��api: " + d.yar��ap); 
        System.out.println ("Dairenin Alan�   : " + d.alan); 
        System.out.println ("Dairenin �evresi : " + d.�evre); 
        System.out.println();			
    } ;

    // A�k�n Kurucu metodunun tan�m�
    public Daire10( int r )
    {
        yar��ap = r ;
        alan    = pi * r * r; 
        �evre   = 2 * pi * r; 				
    };

    public static void main (String args[]) {
        Daire10 d1 = new Daire10(7);	// nesne yarat�l�yor
        d1.yaz(d1);			// yaz metodu �a�r�l�yor

        Daire10 d2 = new Daire10(9);	// nesne yarat�l�yor
        d1.yaz(d2);			// yaz metodu �a�r�l�yor
    } 	
}