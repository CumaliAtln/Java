import java.util.*;

class Toplama3 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Birinci sy�y� giriniz");
        int m = scan.nextInt();
        System.out.println("�kinci sy�y� giriniz");
        int n = scan.nextInt();
   
        System.out.println(m+n);
    }
}