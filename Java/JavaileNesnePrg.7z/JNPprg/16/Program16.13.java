	public class Daire1B {
	
			public static void main(String args[]) {
			
					Daire1B d1B = new Daire1B();
					
					int yar��ap;
					double �evre;
					double alan;
					final double PI = 3.14;
					
					yar��ap = 7;
					alan = PI * yar��ap * yar��ap;
					�evre = 2 * PI * yar��ap;
					
					System.out.println("Dairenin Alan�    : " + alan);
					System.out.println("Dairenin �evresi  : " + �evre);
			}
	}