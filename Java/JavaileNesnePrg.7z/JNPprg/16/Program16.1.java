class Toplama1 {
	
 public static void main(String[] args) {

	System.out.println(3+5);
	}
}