class ToplamaC {
	int m, n, toplam;

	public ToplamaC(int a) {
		m = a;
	};

	public static void main(String[] args) {

		ToplamaC tC = new ToplamaC(9);
		tC.n = 2;
		tC.toplam = tC.m + tC.n;

		System.out.println(tC.toplam);
	}
}