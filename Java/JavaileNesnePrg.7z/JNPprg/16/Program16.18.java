public class Daire6 {

	double yar��ap, alan, �evre;
	public static double PI = 3.14159;
	
	public static void main(String[] args) {

		Daire6 d1B = new Daire6();
		
		Daire6  d1 = new Daire6();			
		d1.yar��ap = 7; 
		d1.alan    = PI * d1.yar��ap * d1.yar��ap ;
		d1.�evre   = 2 * PI * d1.yar��ap ;

System.out.println ("ilk Dairenin Yar��api: " + d1.yar��ap); 
System.out.println ("ilk Dairenin Alan�   : " + d1.alan); 
System.out.println ("ilk Dairenin �evresi : " + d1.�evre); 
System.out.println();

// �ntan�ml� kurucu ikinci nesneyi yarat�yor
	Daire6 d2 = new Daire6();			
		d2.yar��ap = 9;
		d2.alan    = PI * d2.yar��ap * d2.yar��ap ;
		d2.�evre   = 2 * PI * d2.yar��ap ;
		
System.out.println ("ilk Dairenin Yar��api: " + d2.yar��ap); 	
System.out.println ("ilk Dairenin Alan�   : " + d2.alan); 
System.out.println ("ilk Dairenin �evresi : " + d2.�evre); 
	}
}