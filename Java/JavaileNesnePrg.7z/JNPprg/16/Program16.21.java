	class Daire9 {
    int yar��ap; 
    double �evre; 
    double alan; 
    final static double pi = 3.14;

    // Kurucu metodu
    public Daire9( int r )
    {
        yar��ap = r ;
        alan = pi * r * r; 
        �evre = 2 * pi * r; 				
    };

    public static void main (String args[]) {
		
        Daire9 d1 = new Daire9(7);		// nesne yarat�l�yor
        System.out.println ("Dairenin Alan�    : " + d1.alan); 
        System.out.println ("Dairenin �evresi  : " + d1.�evre); 
        System.out.println();

        Daire9 d2 = new Daire9(9);		// nesne yarat�l�yor 

        System.out.println ("Dairenin Alan�   : " + d2.alan); 
        System.out.println ("Dairenin �evresi : " + d2.�evre); 
    } 	
}