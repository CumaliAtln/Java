import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
 
public class FileChannelDemo {
 
    public static void main(String[] args) throws Exception{
 
       String thisFile = "c:/Jprg/Veysel.txt";
       FileInputStream source = new FileInputStream(thisFile);
       FileOutputStream destination = new FileOutputStream("c:/Jprg/outVeysel.txt");
 
       FileChannel sourceFileChannel = source.getChannel();
       FileChannel destinationFileChannel = destination.getChannel();
 
       long size = sourceFileChannel.size();
       sourceFileChannel.transferTo(0,size,destinationFileChannel);
    }
}