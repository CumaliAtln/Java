import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class DosyaOku {

    public static void main(String[] args) {

        FileInputStream fIn;
        FileOutputStream fOut;
        FileChannel fIChan, fOChan;
        long fSize;
        MappedByteBuffer mBuf;

        try {
           fIn = new FileInputStream("c:/Jprg/AVeysel.txt");
           fOut = new FileOutputStream("outVeysel.txt");

           fIChan = fIn.getChannel();
           fOChan = fOut.getChannel();

           fSize = fIChan.size();

           mBuf=fIChan.map(FileChannel.MapMode.READ_ONLY, 0, fSize);

           fOChan.write(mBuf); // this copies the file

           fIChan.close();
           fIn.close();

           fOChan.close();
           fOut.close();
       } catch (IOException exc) {
           System.out.println(exc);
           System.exit(1);
       } catch (ArrayIndexOutOfBoundsException exc) {
           System.out.println("Kaynak dosyadan hedef dosyaya");
           System.exit(1);
        }
    }
}

/**
 DOSTLAR BEN� HATIRLASIN - A�IK VEYSEL

Ben giderim ad�m kal�r,
Dostlar beni hat�rlas�n.
D���n olur, bayram gelir,
Dostlar beni hat�rlas�n.

Can bedenden ayr�lacak,
T�tmez baca, yanmaz ocak,
Selam olsun kucak kucak,
Dostlar beni hat�rlas�n.
*/