    public void nioDosyaYaz(File file) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);
        FileChannel fileChannel = fileOutputStream.getChannel();
        ByteBuffer byteBuffer = null;
        String messageToWrite = null;
        for (int i = 1; i < 1000000; i++) {         
            messageToWrite = "This is a test �����������";
            byteBuffer = ByteBuffer.wrap(messageToWrite.getBytes(Charset
                    .forName("ISO-8859-1")));
            fileChannel.write(byteBuffer);
        }   
    }