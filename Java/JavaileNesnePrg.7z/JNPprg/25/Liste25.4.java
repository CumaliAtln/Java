import java.nio.ByteBuffer;

public class BufferPut {

    public static void main(String[] args) {

        ByteBuffer buffer = ByteBuffer.allocate(20);
        buffer.put((byte) 5);
        buffer.put((byte) 15);
        buffer.put((byte) 25);
        buffer.put((byte) 35);
        buffer.put((byte) 45);
        buffer.put((byte) 50);

        // byte dizisi
        byte[] dizi = new byte[] {51, 52, 53, 54, 55};
        buffer.put(dizi);

        // bufferin ba�lang�� bile�enine yaz
        buffer.put(0, (byte) 60);
        buffer.flip();
        for (int i=0;i<11;i++)
            System.out.print( buffer.get(i));
    }
}