import java.nio.*;

public class BufferNitelikleriDemo{
    public static void main(String[] argv) throws Exception{
        // S��as� 10 olan bo� bir ByteBuffer olu�tur
        ByteBuffer bbuf = ByteBuffer.allocate(10);

        // ByteBuffer'�n s��as�
        int capacity = bbuf.capacity(); // 10

        // get() metodu position g�stergesini etkilemez. 
        byte b = bbuf.get(5); // position=0

        // position'a de�er ver
        bbuf.position(5);

        // g�reli get()
        b = bbuf.get();

        // yeni position
        int pos = bbuf.position(); 

        // kalan byte'lar�n say�s�
        int rem = bbuf.remaining();

        // limit koy
        bbuf.limit(7); // kalan=1

        // position = 0 yap
        bbuf.rewind(); // kalan=7

    }
}