public static void dosyaKopyala(File kaynakFile, File hedefDosya) throws IOException {
 FileChannel kaynak = null;
 FileChannel hedef = null;
 try {
  kaynak = new FileInputStream(kaynakDosya).getChannel();
  hedef = new FileOutputStream(hedefDosya).getChannel();
  hedef.transferFrom(kaynak, 0, kaynak.size());
 }
 finally {
  if(kaynak != null) {
   kaynak.close();
  }
  if(hedef != null) {
   hedef.close();
  }
}