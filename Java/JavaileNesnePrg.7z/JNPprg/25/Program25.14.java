/** 
 VATAN ���N

    Neler yapmad�k �u vatan i�in!
    Kimimiz �ld�k;
    Kimimiz nutuk s�yledik.
            ---Orhan Veli Kan�k---
*/

package javanio;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class DosyaKopyala {

    static public void main(String args[]) throws Exception {
        FileInputStream gelenDosya = new FileInputStream("c:/a/kaynak.txt");
        FileOutputStream gidenDosya = new FileOutputStream("c:/b/hedef.txt");

        FileChannel gelenKanal = gelenDosya.getChannel();
        FileChannel gidenKanal = gidenDosya.getChannel();

        ByteBuffer bb = ByteBuffer.allocate(1024);

        while (true) {
            int ch = gelenKanal.read(bb);
            if (ch == -1) {
                break;
            }
            bb.flip();
            gidenKanal.write(bb);
            bb.clear();
        }
    }
}