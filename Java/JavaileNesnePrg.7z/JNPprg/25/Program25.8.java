import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileChannelDemo2 {
  public static void main(String[] args) throws Exception {
    String fromFileName = "NAZIM.txt";
    String toFileName = "Hikmet.txt";
    FileChannel  in = new FileInputStream(fromFileName).getChannel();
    FileChannel out = new FileOutputStream(toFileName).getChannel();

    ByteBuffer buff = ByteBuffer.allocateDirect(32 * 1024);

    while (in.read(buff) > 0) {
      buff.flip();
      out.write(buff);
      buff.clear();
    }

    in.close();
    out.close();
  }
}

/**
 G�DERAYAK
Giderayak i�lerim var bitirilecek,
giderayak.
Ceylan� kurtard�m avc�n�n elinden
ama daha bayg�n yatar ay�lamad�.
Kopard�m portakal� dal�ndan
ama kabu�u soyulamad�.
Oldum y�ld�zlarla ha��r ne�ir
ama say�s� bir tamam say�lamad�.
Kuyudan �ektim suyu
ama bardaklara konulamad�.
G�ller dizildi tepsiye
ama ta�tan fincan oyulamad�.
Sevdalara doyulamad�.
Giderayak i�lerim var bitirilecek,
giderayak.
     ---NAZIM H�KMET---
*/