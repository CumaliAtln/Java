import java.nio.CharBuffer;

public class BufferRewind {
    public static void main(String[] args) {

        CharBuffer buffer = CharBuffer.allocate(1024);
        buffer.put("En c�mert�e ba���lanan �ey, ���tt�r. --La Rochefoucauld--");
        buffer.flip();

        while (buffer.hasRemaining()) {
            System.out.print(buffer.get());
        }
        System.out.println("");

        buffer.rewind();
        StringBuilder sb = new StringBuilder();
        while (buffer.hasRemaining()) {
            sb.append(buffer.get());
        }
        System.out.println("sb = " + sb);
    }
}