import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class Main {
  public static void main(String[] argv) throws Exception {
    ByteBuffer bbuf = ByteBuffer.allocate(100);
    File file = new File("filename");

    boolean append = false;

    FileChannel wChannel = new FileOutputStream(file, append).getChannel();

    wChannel.write(bbuf);

    wChannel.close();
  }
}