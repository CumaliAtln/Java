import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class BufferRead {
    public static void main(String[] args) throws Exception {
        FileChannel channel = null;

        try {
            /*
             * bir hedef dosya se� ve  FileOutputStream nesnesi yarat
             */
            File file = new File("hedef.txt");
            FileOutputStream fos = new FileOutputStream(file);
            // 256 bile�eni olan bo� bir ByteBuffer olu�tur; i�ine diziyi koy
            ByteBuffer buffer = ByteBuffer.allocate(256);
            buffer.put(new byte[] {65, 66, 67, 68, 69, 70, 71, 72, 73, 74});

            // Yaz�lma kipinden okunma kipine �evir
            buffer.flip();
            // FileOutputStream nesnesinden bir kanal al
            // channel.write() metodu ile arabelle�in i�indekileri yazd�r
            channel = fos.getChannel();
            int bytesWritten = channel.write(buffer);
            System.out.println("written : " + bytesWritten);
        } finally {
            if (channel != null && channel.isOpen()) {
                channel.close();
            }
        }
    }
}