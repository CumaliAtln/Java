import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileChannelDemo {
	static public void main(String args[]) throws Exception {
		FileInputStream gelenDosya = new FileInputStream("Einstein.txt");
		FileOutputStream gidenDosya = new FileOutputStream("gidenEinstein.txt");

		FileChannel gelenKanal = gelenDosya.getChannel();
		FileChannel gidenKanal = gidenDosya.getChannel();

		ByteBuffer bb = ByteBuffer.allocate(1024);

		while (true) {
			int ch = gelenKanal.read(bb);
			if (ch == -1)
				break;
			bb.flip();
			gidenKanal.write(bb);
			bb.clear();
		}
	}
}