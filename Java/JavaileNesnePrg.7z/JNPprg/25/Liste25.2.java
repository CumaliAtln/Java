import java.nio.ByteBuffer;

public class ByteBufferYarat {

    public static void main(String[] argv) throws Exception {
        // Bir byte array ile ByteBuffer yarat�r
        byte[] bytes = new byte[10];
        ByteBuffer buffer = ByteBuffer.wrap(bytes);

        /*
         * S��as� 10 olan dolayl� ByteBuffer yarat�r
         * Yarat�lan nesne (depo) bir byte array �zerindedir
         */
        buffer = ByteBuffer.allocate(10);

        /*
         * S��as� 10 olan dolays�z (memory-mapped) ByteBuffer yarat�r 
         */
        buffer = ByteBuffer.allocateDirect(10);
    }
}