import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class ReadWriteDemo {
  public static void main(String[] argv) throws Exception {
    File file = new File("c:/Jprg/Mevlana.txt");
//  Create a read-write memory-mapped file
    FileChannel rwChannel = new RandomAccessFile(file, "rw").getChannel();

    ByteBuffer writeonlybuffer = rwChannel.map(FileChannel.MapMode.READ_WRITE, 0, (int) rwChannel.size());
  }
}