import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class ReadOnlyDemo {
    public static void main(String[] argv) throws Exception {
        File file = new File("c:/jprg/Wisel.txt");
        // yaln�z okunur dosya yarat
        FileChannel roChannel = new RandomAccessFile(file, "r").getChannel();

        ByteBuffer readonlybuffer = roChannel.map(FileChannel.MapMode.READ_ONLY, 0, (int) roChannel.size());
    }
}