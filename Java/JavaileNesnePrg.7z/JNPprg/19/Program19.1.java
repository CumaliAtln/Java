abstract class Personel
{
    protected int sicilNo;
    protected String soyAd;
    protected String ad;

    public abstract void sicilNoVer(int n);

    public abstract void adVer(String s);

    public abstract void soyAdVer(String str);

    public abstract double �cretHesapla();

    public String g�ncelle()        
    {
        return "���i : " + sicilNo + " " + ad + " " + soyAd +  " g�ncellendi";
    }

    public String ekle()
    {
        return "���i : " + sicilNo + " " + soyAd + " " + ad + " eklendi";
    }

    public String sil()
    {
        return "���i : " + sicilNo + " " +  soyAd + " " + ad +  " silindi";
    }

    public String ara()
    {
        return "���i : " + sicilNo + " " + soyAd + " " + ad + " kay�tl�";
    }
}
class Ki�i extends Personel
{
    public void sicilNoVer(int n){
        sicilNo = n;
    }

    public  void adVer(String s){
        ad = "Demet";
    }

    public  void soyAdVer(String str){
        soyAd = "Erdem";
    }

    public  double �cretHesapla(){
        return 3*1234;
    }
}
public class personelUygula
{
    public static void main(String[] args)
    {
        Personel k = new Ki�i();
        k.sicilNoVer(123);
        k.adVer("Demet");
        k.soyAdVer("Erdem");

        System.out.println(k.sicilNo);
        System.out.println(k.ad);
        System.out.println(k.soyAd);
        System.out.println(k.�cretHesapla());

        System.out.println(k.g�ncelle());
        System.out.println(k.ekle());
        System.out.println(k.sil());
        System.out.println(k.ara());

    }
}
