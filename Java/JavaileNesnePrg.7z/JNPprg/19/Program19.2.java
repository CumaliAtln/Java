	abstract class A {
		abstract void soyutMetot();
	
		void normalMetot() {
	
			System.out.println("Ben soyut s�n�fta somut metodum.");
		}
	}
	
	class B extends A {
	
		void soyutMetot() {
			System.out.println("Ben o�ul s�n�fta, soyut metottan kurgulanm�� metodum.");
		}
	}

		public class UygulamaPrg {
	
		public static void main(String args[]) {
	
			B b = new B();
			b.soyutMetot();
		b.normalMetot();
	}
}