abstract class �ekil {

    double boyut1;
    double boyut2;

    �ekil(double a, double b) {
        boyut1 = a;
        boyut2 = b;
    }
    abstract double alan();
}

class Dikdortgen extends �ekil {

    Dikdortgen(double a, double b) {
        super(a, b);
    }
    double alan() {
        System.out.println("Dikdortgenin alan� :");
        return boyut1 * boyut2;
    }
}
class Ucgen extends �ekil {

    Ucgen(double a, double b) {
        super(a, b);
    }

    // ��gen alan� i�in override
    double alan() {
        System.out.println("��genin alan� :");
        return boyut1 * boyut2 / 2;
    }
}

public class AlanBul {

    public static void main(String args[]) {
        // Sekil f = new Sekil(10, 10); // deyim ge�ersizdir
        // soyut s�n�fa ait nesne yarat�lamaz
        Dikdortgen r = new Dikdortgen(9, 5);
        Ucgen t = new Ucgen(10, 8);
        �ekil ref; // referans de�i�keni tan�ml�yor; nesne i�aret etmiyor
        // deyim ge�erlidir
        ref = r; // alt-s�n�fa ait bir nesneyi i�aret ediyor; deyim ge�erlidir
        System.out.println("Alan = " + ref.alan());
        ref = t; // alt-s�n�fa ait bir nesneyi i�aret ediyor; deyim ge�erlidir
        System.out.println("Alan = " + ref.alan());
    }
}