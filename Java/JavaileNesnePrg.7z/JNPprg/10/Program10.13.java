public class Demo {

	public static void main(String[] args) {

        int[] arr = { 20, 25, 13, 41, 52, 63, -43, -86, 0 };
        for (int i : arr)
        {
            System.out.print(i + " \t " );
        }
    }
}