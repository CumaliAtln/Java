class Kentler
    {
        public static void main(String[] args)
        {
        String[] kent={"Van","Trabzon","Kayseri","Mu�","�zmir"};
            for (int i = 0; i < kent.length; i++)
                System.out.println("kent[" + i + "] = " + kent[i]);
        }
    }