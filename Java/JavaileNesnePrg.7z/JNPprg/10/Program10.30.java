public class Demo {

    public static void main(String[] args){

        int[][] arr;
        // 10 sat�r i�in bellekte yer ay�r
        arr = new int[10][];  
        for (int r=0; r<arr.length; r++) {
            arr[r] = new int[r+1];
        }

        // arrayi tablo halinde yaz
        for (int r=0; r<arr.length; r++) {
            for (int c=0; c<arr[r].length; c++) {
                System.out.print(" " + arr[r][c]);
            }
            System.out.println("");
        }
    }
}