public class Arr3 {
    public static void main(String[] args) {

        int[][] jarr = { { 3, 4, 5 }, { 13, 67 }};
        // �entikli arrayi bildirim an�nda tan�mlar.

        for (int i = 0; i < jarr.length; i++) {
            for (int j = 0; j < jarr[i].length; j++) {
                System.out.print(jarr[i][j] + " ");
            }
            System.out.println();
        }
    }
}