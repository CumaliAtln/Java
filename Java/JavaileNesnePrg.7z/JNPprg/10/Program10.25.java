class Demo {
    public static void main(String[] args)
    {
        int[][] a = new int[][]  { 
                {23, 45, 78},
                {52, 67, 89},
                {2, -56, 65},
                {79, 14, 91},
                { 0, 45, 73},
                {91, 87 ,67},
                {23, 16, 37},
                {17, 43, 58},
                {84, 33, 59},
                {48, 73, 30},
                {74, 86, 15},
                {57,811, 90} };
        for (int i = 0; i < a.length; i++) { 
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j] + " ");
            }
            System.out.println();
        }
    }
}