import java.util.Arrays;

public class Demo {
  public static void main(String args[]) {
    char[] a = { 'A', 'B', 'C', 'D', 'E' };
    char[] b = Arrays.copyOf(a, 3); 
    System.out.println("Kaynak array : " +  Arrays.toString(a));
    System.out.println("Hedef array  : " +  Arrays.toString(b));
  }
}