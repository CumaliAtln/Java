class Array03
{
   public static void main(String[] args)
   {
       int[] intSay� = new int[5];
       for (int i = 0; i < intSay�.length; i++)
       intSay�[i] = i * 10;
       for (int i = 0; i < intSay�.length; i++)
       System.out.println("intSay�[" + i + "] = " + intSay�[i]);
   }
}