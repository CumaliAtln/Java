public class Demo {

	static int n = 10;
	static int[] arr = new int[n];

	static void arrYaz(int[] p) {
		for (int i = 0; i < p.length; i++)
			p[i] = i*3;
	}

	static void arrOku(int[] r) {
		for (int i = 0; i < r.length; i++)
			System.out.print("\t" + r[i]);
	}

	public static void main(String[] args) {
		arrYaz(arr);
		arrOku(arr);
	}
}