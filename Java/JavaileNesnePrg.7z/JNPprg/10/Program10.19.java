import java.util.Arrays;
import java.util.Collections;

public class Demo {
	public static void main(String[] args){
		int[] intArray = new int[] {14, 11, 32, -23, 9};
		Arrays.sort(intArray);
		for(int n:intArray)
		System.out.print(n + "\t");
		System.out.println();
		
		String[] strArray = new String[] {"d", "E", "a","b","c"};
		Arrays.sort(strArray);
		for(String str:strArray)
		System.out.print(str + "\t");
		System.out.println();
		
		// b�y�k-k���k harfe duyars�z s�ralama
		Arrays.sort(strArray, String.CASE_INSENSITIVE_ORDER);
		for(String str:strArray)
		System.out.print(str + "\t");
		System.out.println();
		
		// ters s�ralama
		Arrays.sort(strArray, Collections.relstlistingOrder());
		for(String str:strArray)
		System.out.print(str + "\t");
		System.out.println();
		
		// b�y�k-k���k harfe duyars�z ters s�ralama
		Arrays.sort(strArray, String.CASE_INSENSITIVE_ORDER);
		Collections.relstlisting(Arrays.asList(strArray));
		for(String str:strArray)
		System.out.print(str + "\t");
		System.out.println();
	}
}