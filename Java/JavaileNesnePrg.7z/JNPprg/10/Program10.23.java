public class Demo {

    public static void main(String[] args){

        int[][]  arr = new int[10][5];
        // arrayi bir tablo halinde yaz
        for (int r=0; r<arr.length; r++) {
            for (int c=0; c<arr[r].length; c++) {
                System.out.print(" " + arr[r][c]);
            }
            System.out.println("");
        }
    }
}