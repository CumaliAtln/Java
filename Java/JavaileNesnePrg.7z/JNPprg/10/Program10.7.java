import java.util.Arrays;

public class Demo {
    public static void main(String args[]) {

        int toplam = 0;
        int[] a = { 10,20,30,40,50,60,70,80,90,100};
        for (int i=0; i<a.length;i++)
            toplam = toplam + a[i];
        System.out.println(toplam);
    }
}