public class Atama {

    public static void main(String[] args){
        
        short[] a,b;
        a = new short[]{10,20,30};
        b = a;
        b[2] = a[0];
        System.out.println(b[2]);
    }
}