public class Array01 {

   public static void main(String[] args) {
       String[] meyve = {"elma", "�ilek", "kiraz"};

       int arrayUzunlu�u = meyve.length;
       System.out.format("Bile�en say�s�: %d ", arrayUzunlu�u);
   }
}