class B2Array01
{
    public static void main(String[] args)
    {
        int[][]  ikilSay� = new int[][] { {1, 2}, {3, 4}, {5, 6} };

        System.out.print(ikilSay�[0][0]); System.out.print("\t");
        System.out.println(ikilSay�[0][1]);
        System.out.print(ikilSay�[1][0]); System.out.print("\t");
        System.out.println(ikilSay�[1][1]);
        System.out.print(ikilSay�[2][0]); System.out.print("\t");
        System.out.println(ikilSay�[2][1]);
    }
}