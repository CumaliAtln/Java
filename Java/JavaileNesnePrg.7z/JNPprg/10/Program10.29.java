public class �entikli {
    public static void main(String[] args) {

        int[][] arr = { { 3, 4, 5 }, { 77, 50 }};
        // �entikli array yaratma y�ntemi.

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }
}