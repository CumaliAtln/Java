import java.util.Arrays;

public class Demo {
  public static void main(String args[]) {
    String a[] = { "A", "B", "C", "D", "E" };
    String b[] = Arrays.copyOf(a, 3); 
    System.out.printf("Kaynak array : \t%s%n ", Arrays.toString(a));
    System.out.printf("Hedef array  : \t%s%n ", Arrays.toString(b));
  }
}