import java.util.Arrays;

public class Demo {
    public static void main(String args[]) {

        int toplam = 0;
        int[] a = { 10,20,30,40,50,60,70,80,90,100};
        for (int k : a)
            toplam = toplam + k ;
        System.out.println(toplam);
    }
}