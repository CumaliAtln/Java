class Array02
{
   public static void main(String[] args)
   {
       int[] �arpan = new int[10];
       for (int i = 6; i < 10; i++)
       {
           �arpan[i] = i * i;
       }
       for (int i = 0; i < 10; i++)
       {
           System.out.print(�arpan[i]);
           System.out.print("\t");
       }
   }
}