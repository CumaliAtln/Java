public class Demo {

    public static void main(String[] args){

        int[][] arr = new int [2][3] ;
        arr[0][0] = 1 ; arr[0][1] = 2 ; arr[0][2] = 3 ; 
        arr[1][0] = 4 ; arr[1][1] = 5 ; arr[1][2] = 6 ;
        // arrayi bir tablo halinde yaz
        for (int r=0; r<arr.length; r++) {
            for (int c=0; c<arr[r].length; c++) {
                System.out.print(" " + arr[r][c]);
            }
            System.out.println("");
        }
    }
}