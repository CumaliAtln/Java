class Demo {
    public static void main(String[] args){
        String[][] adSoyad = new String[3][2] ;
        adSoyad[0][0] = "Melih" ;
        adSoyad[0][1] = "Cevdet" ;
        adSoyad[1][0] = "Orhan" ;
        adSoyad[1][1] = "Veli" ;
        adSoyad[2][0] = "Oktay" ;
        adSoyad[2][1] = "R�fat" ;
        int i=0, j=0;
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 2; j++){
                System.out.print("adSoyad["+i+"]["+j+"] = " + adSoyad[i][j]);
                System.out.println();
            }
        }
    }
}