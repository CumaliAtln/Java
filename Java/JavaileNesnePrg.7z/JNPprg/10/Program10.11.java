public class Demo {

	public static void main(String[] args) {
		short[] a = { 8, 7, 6, 5 };
		int[] b = { 2, 3, 324765, 4, 1 };
		System.out.println("b[2] = " + b[2]);
		a[3] = b[2];
		System.out.println("b[2] = " + b[2]);
	}
}