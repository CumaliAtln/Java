public class Demo {

    public static void main(String[] args) {

        char[] kaynak = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j' };
        char[] hedef = new char[5];
        System.arraycopy(kaynak, 1, hedef, 0, 4);
        System.out.println(new String(hedef));
    }
}