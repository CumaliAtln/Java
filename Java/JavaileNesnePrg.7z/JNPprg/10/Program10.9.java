  class Vergi {
	public static void main(String[] args) {

		float[] ayl�k�cret = new float[3];
		ayl�k�cret[0] = 3456.76f;
		ayl�k�cret[1] = 8765.37f;
		ayl�k�cret[2] = 21347.72f;

		float[] gelirVergisi = new float[3];
		for (int i = 0; i < ayl�k�cret.length; i++) {
			gelirVergisi[i] = ayl�k�cret[i] * 30 / 100;

			System.out.println("Ayl�k " + ayl�k�cret[i]
					+ " TL �cretin gelir vergisi =  " + gelirVergisi[i]);
		}
	}
}