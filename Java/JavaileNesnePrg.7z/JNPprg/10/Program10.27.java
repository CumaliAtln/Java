class Atama
{
    public static void main(String[] args)
    {
        int[][] arr = new int[5][4];
        for (int j = 0; j < 4; j++)     // sat�r d�ng�s�
        {
            for (int i = 0; i < 5; i++) //kolon d�ng�s�
            {
                arr[i][ j] = i*j ;       // bile�enlere de�er atar
                System.out.print(arr[i][j]);
                System.out.print("\t");
            }
            System.out.println();
        }
    }
}