import java.util.Arrays;

public class Demo {
  public static void main(String args[]) {
    int[] a = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    int[] b = Arrays.copyOfRange(a, 5, 8); 
    System.out.println("Kaynak array : " +  Arrays.toString(a));
    System.out.println("Hedef array  : " +  Arrays.toString(b));
  }
}