public class Harf implements Runnable{

    public void run(){
        for (int i=0;i<3;i++){
            char c = (char) (65+i);
            System.out.println(c); 
        }
    }
}

public class Zaman implements Runnable{

    public void run(){
        for (int i=0;i<2;i++)
            System.out.println(new java.util.Date());
    }
}

public class Yaz{

    public static void main(String[] args){

        Thread t2 = new Thread(new Harf());
        t2.start();
        Thread t1 = new Thread(new Zaman());
        t1.start();
    }
}