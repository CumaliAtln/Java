public class TestRunnable {
    // thread'leri yarat�yor
    Thread printA = new Thread(new CharYaz('X', 5));
    Thread printB = new Thread(new CharYaz('Y', 5));
    Thread print5 = new Thread(new Say�Yaz(10));
    public static void main(String[] args) {
        new TestRunnable();
    }

    public TestRunnable() {
        //  thread'leri ba�lat�yor
        print5.start();
        printA.start();
        printB.start();
    }
    // harf yazacak thread s�n�f� tan�mlan�yor
    class CharYaz implements Runnable {
        private char harf; // yaz�lacak harf
        private int ka�Kez; // ka�Kez yaz�lacak
        // kurucu
        public CharYaz(char c, int t) {
            harf = c;
            ka�Kez = t;
        }
        // run() metodu bask�lan�yor (override) 
        public void run() {
            for (int i = 0; i < ka�Kez; i++)
                System.out.print(harf);
        }
    }
    // Say� yazacak thread s�n�f� tan�mlan�yor
    class Say�Yaz implements Runnable {
        private int sonSay�;
        // kurucu
        public Say�Yaz(int n) {
            sonSay� = n;
        }
        // run() metodu bask�lan�yor
        public void run() {
            for (int i = sonSay�; i >= 0 ; i--)
                System.out.print(" " + i);
        }
    }
} 