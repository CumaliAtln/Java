public class RunnableTest implements Runnable {
    // run() metodu kurgulan�yor (implement)
    public void run() {
        for (int i=1; i <= 10; i++) {
            System.out.println(i);
        }
    }

    public static void main(String args[]) {
        RunnableTest test = new RunnableTest();
        // thread nesnesi yarat�l�yor
        Thread t = new Thread(test);
        // thread ba�lat�l�yor
        t.start();
        System.out.println("Thread ba�l�yor");
    }
}