public class TestThread3 {

    public static void main(String[] args) {
        // Create threads
        CharYaz printA = new CharYaz('a', 5);
        CharYaz printB = new CharYaz('b', 8);
        Say�Yaz print10 = new Say�Yaz(10);
        // Start threads
        print10.start();
        printA.start();
        printB.start();
    }
}
// Thread s�n�f�n�n geni�letilmesi
class CharYaz extends Thread {
    private char harf; // yaz�lacak karekterler
    private int ka�Kez; // ka� kez yaz�laca��
    // kurucu
    public CharYaz(char c, int t) {
        harf = c;
        ka�Kez = t;
    }
    //  run() metodunun bask�lanmas� (override) 
    public void run() {
        for (int i = 0; i < ka�Kez; i++)
            System.out.print(harf);
    }
}
// Say�lar� yazan thread s�n�f� 
class Say�Yaz extends Thread {
    private int sonSay�;
    // kurucu
    public Say�Yaz(int n) {
        sonSay� = n;
    }
    // run() metodunun bask�lanmas�
    public void run() {
        for (int i = 1; i <= sonSay�; i++)
            System.out.print(" " + i);
    }
} 