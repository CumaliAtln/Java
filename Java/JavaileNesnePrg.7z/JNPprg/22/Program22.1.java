public class ThreadTest extends Thread {
    // run() metodu bask�lan�yor
    public void run() {
        for (int i=1; i <=10; i++) {
            System.out.print(" " +i);
        }
    }

    public static void main(String args[]) {
		
        ThreadTest test = new ThreadTest();
        // thread'i ba�lat
        test.start();
        System.out.println("Thread Ba�l�yor :");
    }
}