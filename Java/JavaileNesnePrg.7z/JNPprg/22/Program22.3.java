public class ThreadTest2 {
    public static void main(String args[]) {
        Say�Yaz A = new Say�Yaz(10);
        Say�Yaz B = new Say�Yaz(20);
        Say�Yaz C = new Say�Yaz(30);
        Say�Yaz D = new Say�Yaz(40);
        A.start();
        B.start();
        C.start();
        D.start();
    }
}

class Say�Yaz extends Thread {
    int say�;
    public Say�Yaz(int x) {
        say�=x;
        System.out.println();
    }

    public void run() {
        int j=0;
        while(j<=3) {
            yaz();
            j++;
        }
    }

    public void yaz() {
        System.out.print(" " + say�);
    }
}