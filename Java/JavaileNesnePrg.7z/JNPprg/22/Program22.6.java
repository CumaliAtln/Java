	public class SleepTest extends Thread {
    public void run() {
        for (int i=0; i < 10; i++) {
            if (i % 2 == 0) System.out.println("Tik"); 
            else System.out.println("Tak");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}
        }
    }

    public static void main(String args[]) {
        SleepTest t = new SleepTest();
        t.start();
    }
}