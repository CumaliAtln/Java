import java.util.Scanner; 

class Kent
{
    String  kentAd�;
    Kent()
    {
        System.out.println("Kent Kurucu" );
    }

    void kentAd�n�Yaz(String kentAd�) 
    {
        System.out.println("Kent 'in ad� : " + kentAd�);

    }
}

class Mahalle extends Kent
{
    String  mahalleAd�;
    Mahalle()
    {
        System.out.println("Mahalle Kurucu.");
    }

    void mahalleAd�n�Yaz(String s)
    {
        System.out.println("Mahalle ad� : " + s);
    }
}
public class Uygulama
{
    public static void main(String[] args)
    {
        Mahalle mahalle = new Mahalle();
        Scanner scan = new Scanner(System.in); 

        System.out.println("Kentin ad�n� giriniz: ");   
        mahalle.kentAd� = scan.next();  
        System.out.println(mahalle.kentAd�);
        mahalle.kentAd�n�Yaz(mahalle.kentAd�);

        System.out.println("Mahalle ad�n� giriniz:  ");
        mahalle.mahalleAd� = scan.next(); 
        mahalle.mahalleAd�n�Yaz(mahalle.mahalleAd�);
    }
}