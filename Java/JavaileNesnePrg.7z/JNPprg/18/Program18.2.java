class Ata
{
    int n;
    int hesap(int m)
    {
        n = m;
        return 2*n;
    }
}

class O�ul extends Ata
{
    double d;

    double hesap(double x)
    {
        d = x;
        return (n+d);
    }
}
public 	class HesapYap
{
    public static void main(String[] args)
    {
        Ata a = new Ata();
        System.out.println(a.hesap(12));    
        O�ul o = new O�ul();
        System.out.println(o.hesap(2.5));
    }
}