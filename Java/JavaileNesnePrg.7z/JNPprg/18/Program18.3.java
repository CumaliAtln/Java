 class �izici
	{
			public void �iz()
			{
					System.out.println("�izici");
			}
	}
	
	 class Do�ru�iz extends �izici
	{
			public  void �iz()
			{
					System.out.println("Do�ru.");
			}
	}
	
	 class Daire�iz extends �izici
	{
			public  void �iz()
			{
					System.out.println("Daire");
			}
	}
	
	 class Kare�iz extends �izici
	{
			public  void �iz()
			{
					System.out.println("Kare");
			}
	}
	
	
	public class Uygulama
	{
			public static void main(String[] args)
			{
					�izici[] bir�izici = new �izici[4];
	
					bir�izici[0] = new Do�ru�iz();
					bir�izici[1] = new Daire�iz();
					bir�izici[2] = new Kare�iz();
					bir�izici[3] = new �izici();
	
					for (�izici saya� : bir�izici)
					{
							saya�.�iz();
					}
	
			}
	}
