import java.util.Date;

public class TarihYaz {

	public static void main(String[] args) {

		Date date = new Date();
		System.out.println(date.toString());
	}
}