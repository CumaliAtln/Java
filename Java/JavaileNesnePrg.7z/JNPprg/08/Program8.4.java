class KesirliSay� {

	public static void main(String[] args) {

		float  f = 987.65432189f;
		double d = 987.65432189;

		System.out.printf("%f \n", f);
		System.out.printf("%f \n", d);
	}
}