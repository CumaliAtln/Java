class TamSay�2 {

    public static void main(String[] args) {
        int i = 1234;

        System.out.printf("|%10d| \n", i);
        System.out.printf("|%-10d| \n", i);
        System.out.printf("|%10d|  |%15d| \n", i, i*10);
    }
}