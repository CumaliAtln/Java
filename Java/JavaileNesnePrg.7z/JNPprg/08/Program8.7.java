class HexYaz {

    public static void main(String[] args) {
        int i = 1234;

        System.out.printf("|%10x| \n", i);
        System.out.printf("|%-10x| \n", i);
        System.out.printf("|%10x|  |%15x| \n", i, i*10);
    }
}