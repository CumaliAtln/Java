public class Karma2 {

	public static void main(String[] args)
	{
		int n = 12345;
		double x = 12345.678901234;
		System.out.printf("|%4d|     %n" , n);
		System.out.printf("|%4.3f|   %n" , x);
		System.out.printf("|%4d|   |%4.3f|  %n" , n, x);
	}
}