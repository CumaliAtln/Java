public class Se� {

    public static void main(String[] args) {

        long   n = 461012;
        float  x = 789.654f;
        double y = 123.45678;

        System.out.printf("%3$012.4f", n, y, x);
    }
}