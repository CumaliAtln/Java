class StringYaz {

    public static void main(String[] args) {

        String str = "�niversite";

        System.out.printf("|%s| \n", str);
        System.out.printf("|%15s| \n", str);
        System.out.printf("|%-15s| \n", str);

    }
}