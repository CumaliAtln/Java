class HexYaz2 {

    public static void main(String[] args) {
        int i = 54321;

        System.out.printf("|%10X| \n", i);
        System.out.printf("|%-10X| \n", i);
        System.out.printf("|%10X|  |%15X| \n", i, i*10);
    }
}