public class Demo {

	public static void main(String[] args)
	{
		for (int i = 2; i <= 1024; i *= 2)
			System.out.printf
			(
				"(%5d, %6.2f, %#10x)\n",
				new Object[]
				{
					new Integer (i),
					new Float ((float) Math.sqrt ((double) i)),
					new Integer (i * i)
				}
			);
	}
}