import java.util.Date;

public class Tarih2 {

	public static void main(String[] args) {

		Date date = new Date();
		System.out.printf("%tc", date);
	}
}