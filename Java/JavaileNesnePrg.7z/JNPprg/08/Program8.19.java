import java.io.*;

public class Demo {

	public static void main(String args[]) {

		StringWriter stringWriter = new StringWriter();
		PrintWriter printWriter = new PrintWriter(stringWriter);

		double r = 123.456789;
		printWriter.format("r = %f", r);
		System.out.println(stringWriter.getBuffer());
	}
}