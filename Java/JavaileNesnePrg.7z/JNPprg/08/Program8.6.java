class OctalYaz {

    public static void main(String[] args) {
        int i = 1234;

        System.out.printf("|%10o| \n", i);
        System.out.printf("|%-10o| \n", i);
        System.out.printf("|%10o|  |%15o| \n", i, i*10);
    }
}