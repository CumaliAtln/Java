import java.io.*;

public class Demo {

	public static void main(String[] args) {

        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);

        printWriter.print(new String("Java �le"));
        printWriter.println();
        printWriter.print(new String("Nesne Programlama"));
        System.out.println(stringWriter.getBuffer());
	}
}