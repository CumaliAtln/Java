import java.io.*;

public class PrintfConsole {

    public static void main(String[] args) {

public class Demo {

	public static void main(String[] args) {

		String nak�� = "%1$4s %2$10s %3$10s%n";

		System.out.printf(nak��, "No", "A", "B");
		System.out.printf(nak��, "-----", "-----", "-----");
		System.out.printf(nak��, "11", "10", "100");
		System.out.printf(nak��, "12", "20", "200");
		System.out.printf(nak��, "13", "30", "300");
		System.out.printf(nak��, "14", "40", "400");
	}
}