class KesirliSay�2 {

    public static void main(String[] args) {
        double dbl = 1234.56;

        System.out.printf("|%10.6f| \n", dbl);
        System.out.printf("|%-10.6f| \n", dbl);
        System.out.printf("|%10.6f|  |%10.6f| \n", dbl, dbl*10);
    }
}