class TamSay� {

    public static void main(String[] args) {

        byte  byt = 12;
        short sht = 123;
        int i = 1234;
        long lng = 12345;

        System.out.printf("%d \n", byt);
        System.out.printf("%d \n", sht);
        System.out.printf("%d \n", i);
        System.out.printf("%d \n", lng);
    }
}