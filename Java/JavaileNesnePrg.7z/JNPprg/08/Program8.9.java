public class Karma1 {

	public static void main(String[] args)
	{
		int n = 123;
		double x = 123.456;
		System.out.printf("%d   %f %n" , n, x);
	}
}