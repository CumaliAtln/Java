import java.io.*;

public class Demo {

	public static void main(String[] args) {

		int ch = 0;
		System.out.println("Bir �eyler yaz:");

		try {
			ch = System.in.read();
			System.out.println("Girilen: " + ch);
		} catch (IOException io) {
			System.out.println("Giri� hatas�!");
		}
	}
}