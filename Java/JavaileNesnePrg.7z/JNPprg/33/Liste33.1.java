	private void jButton2ActionPerformed(
	               java.awt.event.ActionEvent evt)
		{
			  //  float tipi de�i�kenler
			float num1, num2, result;
		
			  // text olarak girilen say�lar float tipe d�n���yor
			num1 = Float.parseFloat(jTextField1.getText());
			num2 = Float.parseFloat(jTextField2.getText());
			
			  // toplama i�lemi yap�l�yor.
			result = num1+num2;
			
			  // Bulunan sonu� jTextField3 alan�na yaz�l�yor.
			  // Alana yazmadan �nce, float say� text'e d�n��t�r�l�yor
			jTextField3.setText(String.valueOf(result));									
		}