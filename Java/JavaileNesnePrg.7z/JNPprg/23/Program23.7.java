import java.io.*;
import java.util.Scanner;

public class FileScanner {
    public static void main(String[] args) throws Exception {
        File file = new File("C:/jprg/Naz�mHikmet.txt");
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            System.out.println(line);
        }
    }
}