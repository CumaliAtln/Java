	import java.util.Scanner; 
	
	public class Metin { 
	
		public static void main(String[] args) { 
			Scanner scan = new Scanner(System.in); 
			System.out.println("L�tfen bir metin giriniz : "); 
			String str = scan.nextLine(); 
			System.out.println(str); 
		} 
	}