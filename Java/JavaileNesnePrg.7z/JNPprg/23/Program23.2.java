	import java.util.Scanner; 
	
	public class BeyazAlan { 
	
		public static void main(String[] args) { 
			Scanner scan = new Scanner(System.in); 
			System.out.println("L�tfen bir metin giriniz : "); 
			while (scan.hasNext()) 
			{ 
			String str = scan.next(); 
			System.out.print(str); 
		} 
		} 
	} 