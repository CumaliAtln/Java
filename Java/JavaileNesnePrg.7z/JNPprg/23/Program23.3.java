	import java.util.Scanner; 
	
	public class Topla { 
	
		public static void main(String[] args) { 
			Scanner scan = new Scanner(System.in); 
			System.out.println("L�tfen ilk tamsay�y� giriniz : "); 
			int n = scan.nextInt(); 
	
			System.out.println("L�tfen ikinci tamsay�y� giriniz : "); 
			int m = scan.nextInt(); 
			System.out.print(n + m); 
		} 
	} 