import java.io.*;
  
public class StandardIO{
  
  public static void main(String[] args) throws IOException{

  InputStreamReader inp = new InputStreamReader(System.in);
    BufferedReader br = new BufferedReader(inp);

    System.out.println("Bir text giriniz : ");
  
 String str = br.readLine();


   System.out.println("Girdi�iniz text : ");

    System.out.println(str);
  }
}