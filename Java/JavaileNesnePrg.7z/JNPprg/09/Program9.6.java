import java.io.*;

public class Demo {

	public static void main(String[] args) {

		byte veri[] = new byte[12];
		try {
			System.out.println(" Bir �eyler yaz ve Entere bas");
			System.in.read(veri);
			System.out.println("Girdi�iniz en �ok ilk 12 	karekter:");

			for (int i = 0; i < veri.length; i++) {

				// Konsola yazmak i�in, girilenleri karektere d�n��t�r

				System.out.print((char) veri[i]);
			}
			System.out.println();
		} catch (IOException e) {
			System.out.print("Veri okunamad�");
		}
	}
}