public class Demo {

	public static void main(String[] args) {

		char input = (char) -1;
		int say�;
		System.out.println("0 ile 10 aras�nda bir say� giriniz :");
		try {
			input = (char) System.in.read();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		say� = Character.digit(input, 10);
		if ((say� > 0) && (say� < 10)) {
			for (int i = 1; i <= say�; i++)
				System.out.println(i);
		} else
			System.out.println("Girdi�iniz say� 0 ile 10 aras�nda de�il!");
	}
}