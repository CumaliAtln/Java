public class Demo {

	public static void main(String[] args) {

		byte dizin[] = new byte[80];
		System.out.println("Bir metin giriniz.");
		try {
			System.in.read(dizin);
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		String str = new String(dizin, 0);
		System.out.println(str);
	}
}