import java.io.IOException;

public class Demo {

	public static void main(String[] args) {

		char ch;
		System.out.println("Bir karekter giriniz:");
		try {
			ch = (char) System.in.read();
			System.out.print("Girdi�iniz karekter :" + ch);
		} catch (IOException e) {
			System.out.println("Giri� okunmad�");
		}
	}
}