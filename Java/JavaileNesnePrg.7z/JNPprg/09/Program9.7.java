import java.util.Scanner;
 
public class SayaklarToplam� {
      public static void main(String[] args) {
            Scanner in = new Scanner(System.in);
            int n;
            System.out.print("Bir do�al say� giriniz: ");
            n = in.nextInt();
            if (n <= 0)
                  System.out.println("Do�al say� girmediniz.");
            else {
                  int toplam = 0;
                  while (n != 0) {
                        // son saya�� toplama ekle
                        toplam += n % 10;
                        // son saya�� at
                        n /= 10;
                  }
                  System.out.println("Sayaklar�n toplam�: " + toplam);
            }
      }
}