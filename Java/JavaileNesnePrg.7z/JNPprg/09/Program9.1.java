import java.io.IOException;

public class Demo {

	public static void main(String[] args) {
		int say�;
		System.out.println("Bir karekter giriniz:");
		try {
			say� = System.in.read();
			System.out.print("Girdi�iniz karekterin ascii kodu : ");
			System.out.println(say�);
		} catch (IOException e) {
			System.out.println("Giri� okunmad�");
		}
	}
}