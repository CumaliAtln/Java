public class Demo {

    public static void main(String[] args) {

        StringBuffer sb = new StringBuffer("Su testisi su yolunda k�r�l�r.");

        System.out.println(sb);

        String str1 = sb.substring(11);
        System.out.println(str1);

        String str2 = sb.substring(0, 11);
        System.out.println(str2);
    }
}