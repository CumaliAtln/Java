		class Str01 {
		public static void main(String args[]) {
	
		System.out.println("Bug�n " + "okula gittim. "
		+ "Java dersini dinledim." );
	}
}