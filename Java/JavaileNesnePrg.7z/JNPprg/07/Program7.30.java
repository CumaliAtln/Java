class Veysel {
    public static void main(String args[]) {

        StringBuilder sb = new StringBuilder("G�l dikende biter, " + "diken g�l olmaz.--A��k Veysel--");

        System.out.println("sb = " + sb.toString());
        sb.delete(0, 19);
        System.out.println("sb = " + sb.toString());

        sb.deleteCharAt(sb.length() - 1);
        System.out.println("sb = " + sb.toString());
    }
}