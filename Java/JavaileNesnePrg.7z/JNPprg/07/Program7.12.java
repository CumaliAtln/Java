public class Demo {

    public static void main(String[] args) {

        char ch;
        String string = "Java Dersleri  ";
        ch = string.charAt(5);

        System.out.println(ch);
    }
}