class Demo {
    public static void main(String args[]) {

        String  str1 = "Merhaba";
        String str2 = "Java";
        String str3 = "  ";
        String str4 = str1+ str3 + str2;

        System.out.println(str4);
    }