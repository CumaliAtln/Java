public class Demo{
    boolean sonu�;
    String str1 = "Marmara bir i� denizdir";
    String s;
    public static void main(String args[]){

        Demo d = new Demo();
        d.s = d.str1;

        d.sonu� = d.s.equals( d.str1 );
        System.out.println(d.sonu�);

        String str2 = "Marmara bir i� denizdir";
        String str3 = "Akdenizi �� k�ta �evreler.";

        d.sonu� = str2.equals( d.str1 );
        System.out.println(d.sonu�);

        d.sonu� = str3.equals( d.str1 );
        System.out.println(d.sonu�); 
    }
}