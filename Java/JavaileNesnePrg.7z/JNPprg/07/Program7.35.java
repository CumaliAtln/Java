class Demo {
    public static void main(String args[]) {

        int m, n = 123;
        String s = String.valueOf(n);
        m = 2*s ;
    }
}