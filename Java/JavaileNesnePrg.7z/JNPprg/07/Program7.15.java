class Demo {

    static String str = "Bu g�n hava �ok so�uktur";
    static boolean b;

    public static void main(String args[]){
        
        b = str.contains("�ok");
        System.out.println(b);
    }
}