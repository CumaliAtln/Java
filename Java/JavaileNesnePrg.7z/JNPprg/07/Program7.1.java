class Demo {
    public static void main(String args[]) {

        String s1 = "Java platform ba��ms�z bir dildir.";
        String s2 = new String("Java ��reniyorum.");
        String s3 = "Merhaba";
        char[] s4 = {'M','e','r','h','a','b','a'};
        String s5 = s2.substring(5,10);

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
        System.out.println(s5);
    }
}