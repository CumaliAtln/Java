	class Str01 {
		public static void main(String[] args){
		System.out.print("Ankara T�rkiye'nin ba�kentidir."); 
		System.out.println("�stanbul ise en b�y�k kentidir.");
		}
	}