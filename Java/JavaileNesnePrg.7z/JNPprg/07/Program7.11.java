public class Demo {

    public static void main(String[] args) {

        String string = " Java Dersleri ";
        String str = string.trim();

        System.out.println("K�rp�lmadan �nce   :" + string);
        System.out.println("K�rp�ld�ktan sonra :" + str);
    }
}