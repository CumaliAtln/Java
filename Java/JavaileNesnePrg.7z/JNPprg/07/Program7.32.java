class Franklin {
    public static void main(String args[]) {

        String str = new String("Sava��n iyisi, bar���n k�t�s� yoktur.\n --Benjamin Franklin--");
        str.toUpperCase();
        System.out.println(str);
    }
}