class Demo {

    static String  str1 = "abc";
    static String str2 = "   ";
    static String str3;  
    static String str4 = null;
    public static void main(String args[]) {

        System.out.println(str1);
        System.out.println(str2);
        System.out.println(str3);
        System.out.println(str4);
        System.out.println(str3.length());
    }
}