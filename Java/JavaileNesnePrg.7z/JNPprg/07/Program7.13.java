			class Str06 {
			public static void main(String args[]) {
			String ob1 = "Bug�n okula gittim. Java dersini dinledim.";
			String ob2 = ob1 ;
	
	System.out.println("ob1 'in uzunlu�u = " + ob1.length()); 
	System.out.println("ob2 'in 21-inci harfi = " + ob1.charAt(20)); 
	
			System.out.println();
	
			System.out.println(ob1.equals(ob2));
			System.out.println(ob1 != ob2);
		}
	}