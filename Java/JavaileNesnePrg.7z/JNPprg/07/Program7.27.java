// Komut sat�r�na metin arrayi yazma
class Demo {
    public static void main(String[] args) { 
        for(int i=0; i<args.length; i++) 
            System.out.println("args[" + i + "]: " + args[i]);
    }
}