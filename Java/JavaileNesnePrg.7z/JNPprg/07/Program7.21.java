		class Str02a {
		public static void main(String args[]) {
		String str1 = "Her ";
		String str2 = "bildi�ini s�yleme, ";
		String str3 = "her s�yledi�ini bil. --Clavdius-- ";

		System.out.println(str1 + str2 + str3);
		}
	}