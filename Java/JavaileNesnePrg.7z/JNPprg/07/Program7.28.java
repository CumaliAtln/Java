public class StringBufferDemo {

    public static void main(String[] args) {
        // StringBuffer kurucular�
        StringBuffer strBuf1 = new StringBuffer("Deha, insan�n kendi ate�ini yakmas�d�r.");
        // 50 karekter s��al� kurucu
        StringBuffer strBuf2 = new StringBuffer(50);  
        // �ntan�ml� 16 karekter s��al� kurucu
        StringBuffer strBuf3 = new StringBuffer(); 

        System.out.println("strBuf1 : " + strBuf1);
        System.out.println("strBuf1 uzunlu�u:"+ strBuf1.length());

        System.out.println("strBuf2 s��as� : " + strBuf2.capacity());
        System.out.println("strBuf3 s��as� : " + strBuf3.capacity());
    }
}