public class Metinler
{
    public static void main(String[] args){

        String str1, str2,str3;
        str1 = "�ki kap�l� bir handa ";
        str2 = "Gidiyorum g�nd�z gece.";
        str3 = str1;
        Boolean b = str1.equals(str3);
        System.out.println(b);
    }
}