public class Demo{

    String str1   = "Avrupa";

    public static void main(String args[]){
        Demo d = new Demo();

        char[] arr = (d.str1).toCharArray();
        for (int i=0;i<arr.length;i++)
        System.out.print(" " +arr[i]);
    }
}