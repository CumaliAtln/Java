	class Str02 {
		public static void main(String[] args){
		String txt1 = new String("Ankara T�rkiye'nin ba�kentidir.");
		String text2 = txt1.concat("�stanbul ise en b�y�k kentidir.");
		System.out.println(text2);
		}
	}