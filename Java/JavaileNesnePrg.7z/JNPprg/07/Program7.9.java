public class Demo{

    Integer say�   = 12345;

    public static void main(String[] args){
        Demo d = new Demo();
        String s = d.say�.toString();
        System.out.println(s);
    }
}