class Str05 {
    public static void main(String args[]) {
        String ob1 = "Anadolu'da �ok tanr�l� inan�� vard�.";
        String ob2 ;

        ob2 = ob1;

        System.out.println("ob1= " + ob1); 
        System.out.println("ob2= " + ob2); 
        System.out.println();

        System.out.println(ob1.equals(ob2)); 
        System.out.println(ob1 == ob2);
    }
}