class Str03 {
    public static void main(String args[]) {

        String str1 = "�aml�belden ";
        String str2 = "��kt�m yayan ";
        String str3 = "dayan dizlerim dayan. ";

        String str4 = "�aml�belden " + "��kt�m yayan. ";
        String str5 = str1 + str2;

        String str6 = str1 + str2 + str3; 
        String str7 = str4 + str3;
        String str8 = str5 + str3;

        System.out.println("str1= " + str1); 
        System.out.println("str2= " + str2); 
        System.out.println("str3= " + str3);

        System.out.println("str4= " + str4); 
        System.out.println("str5= " + str5); 

        System.out.println(); 

        System.out.println("str6= " + str6); 				 			
        System.out.println("str7= " + str7); 
        System.out.println("str8= " + str8);
    }
}