class Demo {

    static String str1 = "Java";
    static String str2 = " platform ba��ms�zd�r.";
    static String str3 = str1.concat(str2);
    public static void main(String[] args){
			System.out.println(str3);
    }
}