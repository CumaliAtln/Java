public class Demo{

   public static void main(String args[]){
      String str1 = "Ankara ba�kenttir";
	    String str2 = "Ankara ba�kenttir";
      String str3 = "�stanbul b�y�k bir metropold�r.";

      int sonu� = str1.compareTo( str2 );
      System.out.println(sonu�);
	  
      sonu� = str2.compareTo( str3 );
      System.out.println(sonu�);
	 
      sonu� = str3.compareTo( str1 );
      System.out.println(sonu�); 
   }
}