public class Demo {

    public static void main(String[] args) {
        char[] arr = {'K','u','�','l','a','r'};
        
        System.out.println(String.valueOf(false)); 				
        System.out.println(String.valueOf('k'));
        System.out.println(String.valueOf(123));
        System.out.println(String.valueOf(35678));
        System.out.println(String.valueOf(12.345));
        System.out.println(String.valueOf(12.45f));
        System.out.println(String.valueOf(arr));        
    }
}