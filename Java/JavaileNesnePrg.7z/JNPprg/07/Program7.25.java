class Str07 {
    public static void main(String[] args){
        String[] str = {"Uzun ", "ince ", "bir ",	"yolday�m ", "gidiyorum ", "g�nd�z ", "gece."}; 
        for (int i = 0; i < str.length; i++) 
            System.out.println("str[" + i + "] = " + str[i]) ;
    }
}