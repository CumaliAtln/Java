class Demo {
    public static void main(String args[]) {

        String str = new String("java");
        str.toUpperCase();
        System.out.println(str);
    }
}