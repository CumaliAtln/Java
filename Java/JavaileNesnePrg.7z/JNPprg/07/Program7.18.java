public class Demo{
    boolean sonu�;
    String str1   = "Marmara";
    String metin  = "MARMARA";

    public static void main(String args[]){
        Demo d = new Demo();

        d.sonu� = (d.metin).equals( d.str1 );
        System.out.println(d.sonu�);

        d.sonu� = d.metin.equalsIgnoreCase(d.str1);
        System.out.println(d.sonu�);
    }
}