class Demo {
    public static void main(String args[]) {

        String  s1 = "Java platform ba��ms�z bir dildir.";
        int n;
        n = s1.length();
        System.out.println(n);
    }
}