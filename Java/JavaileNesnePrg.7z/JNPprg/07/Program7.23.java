class Str04 {
    public static void main(String args[]) {

        String str1 = "�aml�belden ";
        String str2 = "��kt�m yayan ";
        String str3 = "dayan dizlerim dayan. ";

        String str4 = "�aml�belden " + "��kt�m yayan. ";
        String str5 = str1 + str2;

        String str6 = str1 + str2 + str3; 
        String str7 = str4 + str3;
        String str8 = str5 + str3;

        System.out.println(str6.equals(str7)); 
        System.out.println(str6 == str7);

        System.out.println(str6.equals(str8)); 
        System.out.println(str6 == str8);

        System.out.println(str7.equals(str8)); 
        System.out.println(str7 == str7);
    }
}