class Shakspeare {
    public static void main(String args[]) {

        // S��as� 16 karekter olan bir StringBuilder yarat�r
        StringBuilder sb = new StringBuilder();
        // ambara karekter nesneleri koyar
        sb.append("Hi� kimse ");
        sb.append("duymak istemeyen biri ");
        sb.append("kadar sa��r olamaz.\n--W.Shakspeare--");
        System.out.println(sb.toString());
    }
}