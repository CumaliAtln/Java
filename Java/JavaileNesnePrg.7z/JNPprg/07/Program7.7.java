class Demo {

    static char[] arr = {'M','e','r','h','a','b','a'};
    static String str1, str2;

    public static void main(String args[]){
      str1 = String.copyValueOf( arr );
    System.out.println("Array'den kopyalanan metin    : " + str1);

      str2 = String.copyValueOf( arr, 3, 4 );
    System.out.println("Array'den kopyalanan alt metin: " + str2);
    }
}