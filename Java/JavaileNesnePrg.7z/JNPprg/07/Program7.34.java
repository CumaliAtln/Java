class Demo {
    public static void main(String args[]) {

        String str1 = new String("ilkbahar");
        String str2 = new String("ilkbahar");

        if(str1.equals(str2))
            System.out.println("true");
        else
            System.out.println("false");
    }
}