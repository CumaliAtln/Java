interface tiyatro {
    void s�z();
}

class Kerem implements tiyatro {
    public void s�z() {
        System.out.println("S�yle g�zel k�z, sen hangi bah�enin s�mb�l�s�n?");
    }
}

class Asl� implements tiyatro {
    public void s�z() {
        System.out.println("Kerem eyle b�rak beni!");
    }
}

public class Demo {
    public static void main(String args[]) {
        Kerem kerem = new Kerem();
        Asl� asl� = new Asl�();
        konu�(kerem);
        konu�(asl�);
    }

    private static void konu�(tiyatro oyuncu) {
        oyuncu.s�z();
    }
}