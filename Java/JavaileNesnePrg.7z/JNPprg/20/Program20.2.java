import java.util.*;

interface �ekil {
    void �iz();
}

class Daire implements �ekil {
    public void �iz() {
        System.out.println("Daire.�iz()");
    }
}

class Kare implements �ekil {
    public void �iz() {
        System.out.println("Kare.�iz()");
    }
}

class ��gen implements �ekil {
    public void �iz() {
        System.out.println("��gen.�iz()");
    }
}

public class Uygulama {
    public static void main(String[] args) {
        Vector s = new Vector();
        s.addElement(new Daire());
        s.addElement(new Kare());
        s.addElement(new ��gen());
        Enumeration e = s.elements();
        while(e.hasMoreElements())
            ((�ekil)e.nextElement()).�iz();
    }
}