Locale locale = Locale.GERMANY;

String string = NumberFormat.getCurrencyInstance(locale).format(123.45);

// 123,45 DM

	locale = Locale.CANADA;
	
	string = NumberFormat.getCurrencyInstance(locale).format(123.45);
	
	// $123.45
	
	// Parse
	try {
	Number number = NumberFormat.getCurrencyInstance(locale).parse("$123.45");
	
	// 123.45
	if (number instanceof Long) {
	
	// Long value
	} else {
	
	// Double value
	}
	} catch (ParseException e) {
}