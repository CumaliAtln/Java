	import java.text.DateFormat;
	import java.util.Date;
	
	public class Tarih02 {
	
	public static void main(String[] args) {
	//Bir Date nesnesi kur. �imdiki zaman� g�sterir. Date now = new Date();
	
	//	toString() metoduna tarihi yazd�r
	System.out.println(" 1. " + now.toString());
	
	// �ntan�ml� bi�em: DateFormat
	System.out.println(" 2. " + DateFormat.getInstance().format(now));
	
	// �ntan�ml� tarih ve saat:	DateFormats
	System.out.println(" 3. " + DateFormat.getTimeInstance().format(now)); 
	System.out.println(" 4. " + DateFormat.getDateTimeInstance().format(now));
	
	// K�sa, orta ve uzun DateFormat'lar�:
	// �ntan�ml�d�rlar
	System.out.println(" 5. " +	DateFormat.getTimeInstance(DateFormat.SHORT).format(now));
	System.out.println(" 6. " + DateFormat.getTimeInstance(DateFormat.MEDIUM).format(now));
	System.out.println(" 7. " + DateFormat.getTimeInstance(DateFormat.LONG).format(now));
	}
}