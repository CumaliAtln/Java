	formatter = new DecimalFormat("#E0"); // herhangi bir �stel ifade olabilir 
	s = formatter.format(-1234.567); // ��kt�: -.1E4
	s = formatter.format(-.1234567); // ��kt�: -.1E0
	
	formatter = new DecimalFormat("##E0"); // �stel ifadenin �arpan� 2 haneli olur 
	s = formatter.format(-1234.567); // ��kt�: -12E2
	s = formatter.format(-123.4567); // ��kt�: -1.2E2
	s = formatter.format(-12.34567); // ��kt�:-12E0