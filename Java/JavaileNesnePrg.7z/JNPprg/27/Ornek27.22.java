	Locale locale = Locale.CANADA;
	// 12,345%
	String string = NumberFormat.getPercentInstance(locale).format(123.45); 
	
	// Parse try {
	Number number = NumberFormat.getPercentInstance(locale).parse("123.45%");
	
	// 1.2345
		if (number instanceof Long) {
	// Long value
	   } else {
	
	// Double value
	   }
 }  catch (ParseException e) {
}