	NumberFormat formatter = new DecimalFormat("000000"); 
	String s = formatter.format(-1234.567); // ��kt�: -001235