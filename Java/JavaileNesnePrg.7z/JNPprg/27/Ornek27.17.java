	import java.util.Formatter;
	
	public class Giri���k�� {
				public static void main(String args[]) { 
				Formatter fmt = new Formatter();
	
				// 4 ondal�k hane yaz. fmt.format("%.4f", 123.1234567); 
				System.out.println(fmt);
	
				// 16 hanelik yere 2 ondal�k haneli yaz. fmt = new Formatter(); 
				fmt.format("%16.2e", 123.1234567); 
				System.out.println(fmt);
	
				// En �ok 16 karakter yaz. fmt = new Formatter();
				fmt.format("%.16s", "Java ile ��kt�y� bi�emleme �ok kolayd�r."); 
				System.out.println(fmt);
				}
	}