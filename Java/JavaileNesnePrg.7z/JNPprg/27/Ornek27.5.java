import java.io.*;
import java.util.Formatter;

public class FormaterDemo
{
    public static void main (String arg[]) {
        Formatter formatter = null;
        File file = null;

        // dosya ad�n� args'den al
        if (arg.length > 0) file = new File (arg[0]);
        // de�ilse default dosya kullan
        if (file == null) {
            System.out.println ("Default: textHedef.txt");
            file = new File ("textHedef.txt");
        }

        // bi�emleneni dosyaya yaz
        try {
            formatter = new Formatter (file);
        }
        catch  (FileNotFoundException e) {
            // dosya bulunmazsa
            // Formatter yeni dosya a�ar
         }

        formatter.format ("Formatter ile text yazd�rma. %n");
        formatter.format ("�lkel tipler stringe d�n���r %n");

        boolean mant�ksal =  false;
        byte    byteSay�    =  123;
        short   shortSay�   =  1234;
        int     intSay�    =  1234567;
        long    longSay�    =  123456789;
        float   floatSay�   =  123.7f;
        double  doubleSay�  = -7.12345e-15;

        formatter.format ("boolean = %9b %n",   mant�ksal);
        formatter.format ("byte    = %9d %n",   byteSay�);
        formatter.format ("short   = %9d %n",   shortSay�);
        formatter.format ("int     = %9d %n",   intSay�);
        formatter.format ("long    = %9d %n",   longSay�);
        formatter.format ("float   = %9.3f %n", floatSay�);
        formatter.format ("double  = %9.2e %n", doubleSay�);

        // veriyi bufferdan g�nder
        formatter.flush ();
        formatter.close ();
    } 
} 