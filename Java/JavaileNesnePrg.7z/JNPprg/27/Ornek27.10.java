import java.util.Calendar; 
class CalendarDemo { 
    public static void main(String args[]) { 

        Calendar calendar = Calendar.getInstance(); 
        //�imdiki zaman
        System.out.print("Tarih: "); 
        System.out.print(calendar.get(Calendar.MONTH)); 
        System.out.print(" " + calendar.get(Calendar.DATE) + " "); 
        System.out.println(calendar.get(Calendar.YEAR)); 
        System.out.print("Zaman: "); 
        System.out.print(calendar.get(Calendar.HOUR) + ":"); 
        System.out.print(calendar.get(Calendar.MINUTE) + ":"); 
        System.out.println(calendar.get(Calendar.SECOND)); 
        // Yeni zaman koy
        calendar.set(Calendar.HOUR, 10); 
        calendar.set(Calendar.MINUTE, 29); 
        calendar.set(Calendar.SECOND, 22); 
        System.out.print("G�ncellenen zaman : "); 
        System.out.print(calendar.get(Calendar.HOUR) + ":"); 
        System.out.print(calendar.get(Calendar.MINUTE) + ":"); 
        System.out.println(calendar.get(Calendar.SECOND)); 
    } 
}