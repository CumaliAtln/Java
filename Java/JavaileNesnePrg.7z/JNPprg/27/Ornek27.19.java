	formatter = new DecimalFormat("0.0E0");
	s = formatter.format(-1234.567); // ��kt�: -1.2E3
	
	formatter = new DecimalFormat("00.00E0");
	s = formatter.format(-1234.567); // ��kt�: -12.35E2
	
	s = formatter.format(-.1234567); // ��kt�: -12.35E-2