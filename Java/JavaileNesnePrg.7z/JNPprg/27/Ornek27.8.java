	formatter = new DecimalFormat("#,###,###");
	
	s = formatter.format(-1234.567); // ��kt�: -1,235
	
	s = formatter.format(-1234567.890); // ��kt�: -1,234,568