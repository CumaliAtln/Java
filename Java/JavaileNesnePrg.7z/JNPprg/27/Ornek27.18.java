				NumberFormat formatter = new DecimalFormat("0E0"); 
				String s = formatter.format(-1234.567); // -1E3
	
				formatter = new DecimalFormat("00E00");
				s = formatter.format(-1234.567); // -12E02
	
				formatter = new DecimalFormat("000E00");
				s = formatter.format(-1234.567); // -123E01
	
				formatter = new DecimalFormat("0000000000E0");
				s = formatter.format(-1234.567); // -1234567000E-6