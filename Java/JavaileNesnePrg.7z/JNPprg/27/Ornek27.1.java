	public class KesirliSay�Bi�emle {
	
				public static void main(String[] args) {
				int x = 37; String s;
				//s = x;	// Ge�ersiz
				s = "" + x;	// 37 tamsay�s� "37" Stringine d�n���r
				System.out.println(s);
				s = x + " is OK";	// s Stingine "37 is OK" de�erini atar
				System.out.println(s);
				s = "" + 3.5;	// s Stringine "3.5" de�erini atar
				System.out.println(s);
				s = "" + 1.0/3.0;	//	s = "0.3333333333333333" atamas�
				System.out.println(s);
				}
	}