	import java.util.Calendar;
	import java.util.Formatter;
	
	public class DateTimeDemo {
				public static void main(String args[]) { 
				Formatter fmt = new Formatter(); 
				Calendar cal = Calendar.getInstance();
	
				// Standart 12 saat zaman bi�eminde yaz. fmt.format("%tr", cal); 
				System.out.println(fmt);
	
				// Tarih ve zaman� tam bi�emiyle yaz. fmt = new Formatter(); 
				fmt.format("%tc", cal); System.out.println(fmt);
	
				// Yaln�z saat ve dakikay� g�ster. fmt = new Formatter();
	
				fmt.format("%tl:%tM", cal, cal); 
				System.out.println(fmt);
	
				// Ay ad�n� ve s�ras�n� g�ster. fmt = new Formatter();
				fmt.format("%tB %tb %tm", cal, cal, cal); 
				System.out.println(fmt);
			}
	}