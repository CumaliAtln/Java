	DecimalFormat df = new DecimalFormat("#.#####");
	df.format(0.912385);
	//��kt�: 0.91238