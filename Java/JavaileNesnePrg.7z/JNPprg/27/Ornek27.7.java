	formatter = new DecimalFormat(".00");
	s = formatter.format(-.567); // ��kt�: -.57
	
	formatter = new DecimalFormat("0.00");
	s = formatter.format(-.567); // ��kt�: -0.57
	
	formatter = new DecimalFormat("#.#");
	s = formatter.format(-1234.567); // ��kt�: -1234.6
	
	formatter = new DecimalFormat("#.######");
	s = formatter.format(-1234.567); // ��kt�: -1234.567
	
	formatter = new DecimalFormat(".######");
	s = formatter.format(-1234.567); // ��kt�: -1234.567
	
	formatter = new DecimalFormat("#.000000");
	s = formatter.format(-1234.567); // ��kt�: -1234.567000