// FlowLayout Manager 
import java.awt.*;

class FlowLayoutTest extends Frame {

	Button b1 = new Button("Ana Okulu");
	Button b2 = new Button("�lk��retim Okulu");
	Button b3 = new Button("Lise");
	Button b4 = new Button("�niversite");
	Button b5 = new Button("Y�ksek Lisans");


	public FlowLayoutTest(String ad){

		super(ad);
		setLayout( new FlowLayout(FlowLayout.CENTER));
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		add(b1);
	}

	public static void main(String args[]) {
		
		FlowLayoutTest t = new FlowLayoutTest("FlowLayout");
		t.setSize(300 ,200);
		t.show();
	}
}