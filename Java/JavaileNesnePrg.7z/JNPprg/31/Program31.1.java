import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;


public class MutlakDemo extends JFrame {


    public MutlakDemo() {

        initUI();
    }

    public final void initUI() {

        setLayout(null);

        JButton ok = new JButton("Evet");
        ok.setBounds(50, 50, 80, 25);

        JButton close = new JButton("Hay�r");
        close.setBounds(150, 50, 80, 25);

        add(ok);
        add(close);

        setTitle("Mutlak konu�land�rma :");
        setSize(300, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                MutlakDemo ex = new MutlakDemo();
                ex.setVisible(true);
            }
        });
    }
}