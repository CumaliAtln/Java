import java.awt.*;
public class GridLayoutB extends Frame{
public static void main(String argv[]){
        GridLayoutB grid=new GridLayoutB();
        // 2 sat�r ve 5 kolonlu grid yap
        grid.setLayout(new GridLayout(2,5));
        grid.setSize(300,200);
        grid.setVisible(true);
    }
GridLayoutB(){
       add(new Button("Bir"));
        add(new Button("�ki"));
        add(new Button("��"));
        add(new Button("D�rt"));
        add(new Button("Be�"));
        add(new Button("Alt�"));
        add(new Button("Yedi"));
        add(new Button("Sekiz"));
        add(new Button("Dokuz"));
        add(new Button("On"));
        }
}