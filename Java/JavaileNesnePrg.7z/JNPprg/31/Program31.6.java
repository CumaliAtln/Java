import java.awt.*;

public class FlowLayoutB extends Frame{
    public static void main(String argv[]){
        FlowLayoutB fly=new FlowLayoutB();
        fly.setLayout(new FlowLayout());
        fly.setSize(400,300);
        fly.setVisible(true);
    }
    FlowLayoutB(){
        add(new Button("Bir"));
        add(new Button("�ki"));
        add(new Button("��"));
        add(new Button("D�rt"));
        add(new Button("Be�"));
        add(new Button("Alt�"));
        add(new Button("Yedi"));
        add(new Button("Sekiz"));
        add(new Button("Dokuz"));
        add(new Button("On"));
    }
}