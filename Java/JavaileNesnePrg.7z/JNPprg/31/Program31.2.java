//BorderLayout Manager
import java.awt.*;

public class BorderLayoutA extends Frame {

    public BorderLayoutA(String title) {
        super(title);
        add("North" , new Button("Kuzey"));
        add("South" , new Button("G�ney"));
        add("East"  , new Button("Do�u"));
        add("West"  , new Button("Bat�"));
        add("Center", new Button("Orta"));
    }

    public static void main(String[] args) {
     BorderLayoutA blt = new BorderLayoutA("BorderLayout Testi");
     blt.setSize(300, 200);
     blt.setVisible(true);	     
    }
} 