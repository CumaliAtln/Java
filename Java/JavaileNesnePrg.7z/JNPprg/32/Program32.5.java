import javax.swing.*;

public class Demo extends javax.swing.JFrame {
    JTextField username = new JTextField(15);
    JPasswordField password = new JPasswordField(15);
    JTextArea comments = new JTextArea(4, 15);
    JButton ok = new JButton( "Evet");
    JButton cancel = new JButton( "Hay�r");
    public Denetim() {
        super( "Hesap Bilgileri");
        setSize(300, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel pane = new JPanel();
        JLabel usernameLabel = new JLabel( "Kullan�c�:  ");
        JLabel passwordLabel = new JLabel( "�ifre:  ");
        JLabel commentsLabel = new JLabel( "A��klama:  ");
        comments.setLineWrap(true);
        comments.setWrapStyleWord(true);
        pane.add(usernameLabel);
        pane.add(username);
        pane.add(passwordLabel);
        pane.add(password);
        pane.add(commentsLabel);
        pane.add(comments);
        pane.add(ok);
        pane.add(cancel);
        add(pane);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        Denetim auth = new Denetim();
    }
}