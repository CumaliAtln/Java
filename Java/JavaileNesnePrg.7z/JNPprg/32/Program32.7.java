import javax.swing.*;

public class JComboBoxYap extends JFrame {
    String[] formats = { "TRT3", "Maydanoz", "RadyoBa�kent", "BBC" };
    JComboBox formatBox = new JComboBox();

    public JComboBoxYap() {
        super("KanalSe�");
        setSize(220, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pane = new JPanel();
        JLabel formatLabel = new JLabel("Se�ilen Kanal");
        pane.add(formatLabel);
        for (int i = 0; i < formats.length; i++)
            formatBox.addItem(formats[i]);
        pane.add(formatBox);
        add(pane);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        JComboBoxYap ff = new JComboBoxYap();
    }
}