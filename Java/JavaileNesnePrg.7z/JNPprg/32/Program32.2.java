import javax.swing.*;

public class SwingFrame{
  public static void main(String[] args){
  JFrame frame = new JFrame("JFrame A");
  frame.setSize(300, 200);
  frame.setVisible(true);
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
}