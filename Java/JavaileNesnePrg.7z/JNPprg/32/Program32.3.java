import javax.swing.JFrame;

public class BasitJFrame extends JFrame {
    public BasitJFrame() {
        super("Frame Title");
        setSize(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        BasitJFrame sf = new BasitJFrame();
    }
}