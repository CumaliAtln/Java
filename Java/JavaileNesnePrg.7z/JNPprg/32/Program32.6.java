import javax.swing.*;

public class HaberKanal� extends JFrame {
    JRadioButton[] teams = new JRadioButton[4];

    public HaberKanal�() {
        super("��k�� Bi�emini Se�");
        setSize(320, 120);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        teams[0] = new JRadioButton("TRT3");
        teams[1] = new JRadioButton("Maydanoz");
        teams[2] = new JRadioButton("Radyo Ba�kent");
        teams[3] = new JRadioButton("BBC", true);
        JPanel panel = new JPanel();
        JLabel chooseLabel = new JLabel("Haber kanal�n� se�");
        panel.add(chooseLabel);
        ButtonGroup group = new ButtonGroup();
        for (int i = 0; i < teams.length; i++) {
            group.add(teams[i]);
            panel.add(teams[i]);
        }
        add(panel);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        HaberKanal� ff = new HaberKanal�();
    }
}