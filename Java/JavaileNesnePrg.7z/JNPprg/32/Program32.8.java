import javax.swing.*;

public class JListYap extends JFrame {
    String[] subs = { "Biyoloji", "Fizik",
            "Kimya", "Matematik", "Bilgisayar", "�statistik",
            "Ekonomi", "Hukuk", "T�p", "Eczac�l�k" };
    JList subList = new JList(subs);

    public JListYap() {
        super("JListYap");
        setSize(150, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        JLabel subLabel = new JLabel("B�l�mlerin Listesi");
        panel.add(subLabel);
        subList.setVisibleRowCount(8);
        JScrollPane scroller = new JScrollPane(subList);
        panel.add(scroller);
        add(panel);
        setVisible(true);
    }

    public static void main(String[] arguments) {
        JListYap app = new JListYap();
    }
 }