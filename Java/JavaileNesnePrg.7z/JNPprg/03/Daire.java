Class Daire
	{
		final double PI = 3.14159;  \index{PI}
		short yar��ap ;
    static double daireninAlan�;
		...
	}