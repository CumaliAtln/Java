public class Demo {

	public static void main(String[] args) {
		
		double e = 2.71828;

		System.out.println(e);
	}
}