class Demo {

	public static void main(String[] args) {
		
		int min = Integer.MIN_VALUE -1;
		int max = Integer.MAX_VALUE +1;
		
		int a = min - 1;
		int b = max + 1;

		System.out.println("min - 1 = " + a);
		System.out.println("max + 1 = " + b);
	}
}