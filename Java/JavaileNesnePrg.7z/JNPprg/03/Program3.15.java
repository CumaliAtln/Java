public class Daire {

    final static double PI = 3.14159;
    short r;
    static double alan;
    public static void main(String[] args){

        Daire d1 = new Daire();
        d1.r = 3;
        alan = PI * d1.r * d1.r;  
        System.out.println(alan);

        Daire d2 = new Daire();
        d2.r = 5;
        alan = PI * d2.r * d2.r;  
        System.out.println(alan);
    }
}