public class Demo {

	static double e;

	public static void main(String[] args) {

		// e = 2.71828;

		System.out.println(e);
	}
}