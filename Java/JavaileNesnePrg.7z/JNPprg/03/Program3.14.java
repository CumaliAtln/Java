public class Demo {

	static final double PI = 3.14159;

	public static void main(String[] args) {

		System.out.println(PI);
	}
}