public class Demo {

	static double e = 2.71828;

	public static void main(String[] args) {

		System.out.println("ilk e = " + e);
		e = 7.0;
		System.out.println("sonraki e = " + e);
	}
}