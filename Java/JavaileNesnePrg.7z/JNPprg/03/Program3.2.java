class Demo {

	public static void main(String[] args) {

		int toplam = 0;
		for (int i = 0; i < 31; i++)
			toplam = toplam + (int) Math.pow(2, i);
		System.out.println(toplam);
	}
}