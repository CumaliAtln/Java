class Demo {

	public static void main(String[] args) {

		System.out.println(4.0 / 0.0); 	// ��kt�: Infinity
		System.out.println(-4.0 / 0.0); // ��kt�: -Infinity
		System.out.println(0.0 / 0.0); 	// ��kt�: NaN
	}
}